import React, { useState } from 'react';
import {
  ArrowLeft,
  Phone,
  Video,
  Search,
  MoreVertical,
  Lock,
  Unlock,
  Trash2,
  Download,
  Sparkles,
  Clock,
  BellOff,
  Image as ImageIcon,
  Info
} from 'lucide-react';
import { UserContact, UserProfile } from '../types';

interface ChatHeaderProps {
  contact: UserContact;
  currentUser: UserProfile;
  onBackMobile: () => void;
  onStartVoiceCall: () => void;
  onStartVideoCall: () => void;
  onToggleSearch: () => void;
  onToggleLockChat: () => void;
  onClearChat: () => void;
  onExportChat: () => void;
  onOpenAI: () => void;
  onViewScheduled: () => void;
  onViewMediaDocs: () => void;
  onViewContactInfo: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  contact,
  currentUser,
  onBackMobile,
  onStartVoiceCall,
  onStartVideoCall,
  onToggleSearch,
  onToggleLockChat,
  onClearChat,
  onExportChat,
  onOpenAI,
  onViewScheduled,
  onViewMediaDocs,
  onViewContactInfo,
  isMuted,
  onToggleMute
}) => {
  const [showMenu, setShowMenu] = useState(false);

  const isChatLocked = currentUser.lockedChats?.includes(contact.email.toLowerCase());

  return (
    <div className="h-16 px-4 bg-[#0d1220]/95 border-b border-slate-800/80 backdrop-blur-md flex items-center justify-between z-20 shrink-0 select-none">
      {/* Left: Contact Details */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onBackMobile}
          className="md:hidden p-1.5 -ml-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-colors"
          title="Back to contacts"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div
          onClick={onViewContactInfo}
          className="relative cursor-pointer shrink-0"
          title="View Contact Info"
        >
          {contact.profilePhoto ? (
            <img
              src={contact.profilePhoto}
              alt={contact.name}
              className="w-10 h-10 rounded-xl object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 flex items-center justify-center text-base border border-purple-500/20">
              {contact.emoji || '👤'}
            </div>
          )}
          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#0d1220]" />
        </div>

        <div
          onClick={onViewContactInfo}
          className="min-w-0 cursor-pointer text-left"
        >
          <div className="flex items-center gap-1.5">
            <h3 className="text-xs sm:text-sm font-bold text-slate-100 truncate">{contact.name}</h3>
            {contact.emoji && <span className="text-xs">{contact.emoji}</span>}
            {isChatLocked && <Lock className="w-3 h-3 text-amber-400" />}
            {isMuted && <BellOff className="w-3 h-3 text-slate-500" />}
          </div>
          <p className="text-[11px] text-emerald-400 font-medium leading-none mt-0.5">
            online <span className="text-slate-500 font-normal hidden sm:inline">• {contact.about || 'Available on ChatPro'}</span>
          </p>
        </div>
      </div>

      {/* Right: Calls & Actions */}
      <div className="flex items-center gap-1 sm:gap-2">
        <button
          type="button"
          onClick={onStartVoiceCall}
          className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          title="Voice Call"
        >
          <Phone className="w-4 h-4 text-purple-400" />
        </button>

        <button
          type="button"
          onClick={onStartVideoCall}
          className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          title="Video Call"
        >
          <Video className="w-4 h-4 text-teal-400" />
        </button>

        <button
          type="button"
          onClick={onToggleSearch}
          className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          title="Search in conversation"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* WhatsApp-style Three-Dot Menu */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
            title="More Options"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-12 w-52 bg-[#121829] border border-slate-700/80 rounded-xl shadow-2xl p-1.5 z-50 text-xs space-y-0.5 animate-in fade-in zoom-in-95 duration-150">
              <button
                onClick={() => {
                  setShowMenu(false);
                  onViewContactInfo();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                <Info className="w-3.5 h-3.5 text-slate-400" />
                <span>Contact info</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onViewMediaDocs();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-slate-400" />
                <span>Media, links & docs</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onToggleMute();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                <BellOff className="w-3.5 h-3.5 text-slate-400" />
                <span>{isMuted ? 'Unmute notifications' : 'Mute notifications'}</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onToggleLockChat();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                {isChatLocked ? <Unlock className="w-3.5 h-3.5 text-amber-400" /> : <Lock className="w-3.5 h-3.5 text-amber-400" />}
                <span>{isChatLocked ? 'Unlock this chat' : 'Lock this chat'}</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onViewScheduled();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>Scheduled messages</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenAI();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-purple-300 hover:bg-purple-950/40 flex items-center gap-2.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>ChatPro AI Assistant</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onExportChat();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>Export chat history</span>
              </button>

              <div className="border-t border-slate-800 my-1" />

              <button
                onClick={() => {
                  setShowMenu(false);
                  onClearChat();
                }}
                className="w-full px-2.5 py-2 rounded-lg text-left text-rose-400 hover:bg-rose-950/40 flex items-center gap-2.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear chat</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
