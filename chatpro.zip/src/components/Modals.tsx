import React, { useState } from 'react';
import {
  X,
  BarChart2,
  Clock,
  Send,
  Plus,
  Trash2,
  Download,
  Share2,
  Calendar,
  User,
  Info
} from 'lucide-react';
import { UserContact, ChatMessage } from '../types';

// 1. Media Viewer Lightbox
export const MediaLightboxModal: React.FC<{
  isOpen: boolean;
  mediaUrl: string | null;
  mediaType: 'photo' | 'video';
  onClose: () => void;
}> = ({ isOpen, mediaUrl, mediaType, onClose }) => {
  if (!isOpen || !mediaUrl) return null;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-70 flex items-center justify-center p-4">
      <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
        <button
          type="button"
          onClick={onClose}
          className="absolute -top-12 right-0 p-2 rounded-full bg-slate-800 text-white hover:bg-slate-700 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {mediaType === 'photo' ? (
          <img
            src={mediaUrl}
            alt="Preview"
            className="max-w-full max-h-[85vh] rounded-2xl object-contain shadow-2xl border border-slate-800"
          />
        ) : (
          <video
            src={mediaUrl}
            controls
            autoPlay
            className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl border border-slate-800"
          />
        )}
      </div>
    </div>
  );
};

// 2. Poll Creator Modal (Section 20)
export const PollCreatorModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onCreatePoll: (question: string, options: string[]) => void;
}> = ({ isOpen, onClose, onCreatePoll }) => {
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  if (!isOpen) return null;

  const handleAddOption = () => {
    if (options.length < 4) {
      setOptions([...options, '']);
    }
  };

  const handleRemoveOption = (idx: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== idx));
    }
  };

  const handleOptionChange = (idx: number, val: string) => {
    const updated = [...options];
    updated[idx] = val;
    setOptions(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    const cleanOptions = options.map((o) => o.trim()).filter(Boolean);
    if (cleanOptions.length < 2) {
      alert('Poll requires at least 2 non-empty options.');
      return;
    }
    onCreatePoll(question.trim(), cleanOptions);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-60 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-purple-400" />
            <span>Create Poll</span>
          </h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Question</label>
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask a question..."
              className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-slate-300 font-semibold">Options (2 to 4)</label>
            {options.map((opt, i) => (
              <div key={i} className="flex items-center gap-2">
                <input
                  type="text"
                  value={opt}
                  onChange={(e) => handleOptionChange(i, e.target.value)}
                  placeholder={`Option ${i + 1}`}
                  className="flex-1 px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
                />
                {options.length > 2 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveOption(i)}
                    className="p-2 text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {options.length < 4 && (
            <button
              type="button"
              onClick={handleAddOption}
              className="text-xs text-purple-300 hover:text-purple-200 flex items-center gap-1 font-medium cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Add Option
            </button>
          )}

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold flex items-center justify-center gap-1 shadow-md shadow-purple-600/25"
            >
              <BarChart2 className="w-3.5 h-3.5" />
              <span>Send Poll</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 3. Schedule Message Modal (Section 22)
export const ScheduleModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onScheduleMessage: (text: string, date: string, time: string) => void;
}> = ({ isOpen, onClose, onScheduleMessage }) => {
  const [text, setText] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState('12:00');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onScheduleMessage(text.trim(), date, time);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-60 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>Schedule Message</span>
          </h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Message Content</label>
            <textarea
              rows={3}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type message to release at specified time..."
              className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Time</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-slate-100"
              />
            </div>
          </div>

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center justify-center gap-1 shadow-md shadow-indigo-600/25"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Set Schedule</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 4. Forward Message Modal (Section 55)
export const ForwardModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  message: ChatMessage | null;
  contacts: UserContact[];
  onConfirmForward: (targetEmail: string) => void;
}> = ({ isOpen, onClose, message, contacts, onConfirmForward }) => {
  if (!isOpen || !message) return null;

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-60 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Share2 className="w-4 h-4 text-sky-400" />
            <span>Forward Message</span>
          </h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3 bg-[#0a0d18] rounded-xl border border-slate-800 text-xs text-slate-300">
          <span className="text-[10px] text-slate-500 block mb-1">Message Preview:</span>
          <p className="truncate">{message.text || `[${message.messageType}]`}</p>
        </div>

        <div className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar">
          <span className="text-[11px] font-semibold text-slate-400">Select Contact:</span>
          {contacts.map((c) => (
            <button
              key={c.email}
              type="button"
              onClick={() => {
                onConfirmForward(c.email);
                onClose();
              }}
              className="w-full p-2 rounded-xl bg-slate-800/60 hover:bg-purple-900/30 text-left flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-lg bg-purple-600/20 flex items-center justify-center text-xs">
                {c.emoji || '👤'}
              </div>
              <div className="min-w-0 flex-1 truncate">
                <span className="font-semibold block truncate">{c.name}</span>
                <span className="text-[10px] text-slate-400 block truncate">{c.email}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// 5. Contact Info & History Export Dialog (Section 50)
export const ContactInfoModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  contact: UserContact | null;
  messageCount: number;
  onExportChat: () => void;
}> = ({ isOpen, onClose, contact, messageCount, onExportChat }) => {
  if (!isOpen || !contact) return null;

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-60 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Info className="w-4 h-4 text-teal-400" />
            <span>Contact Information</span>
          </h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex flex-col items-center text-center p-2">
          {contact.profilePhoto ? (
            <img
              src={contact.profilePhoto}
              alt={contact.name}
              className="w-20 h-20 rounded-2xl object-cover ring-2 ring-purple-500/40 mb-3"
            />
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-purple-600/30 flex items-center justify-center text-4xl mb-3">
              {contact.emoji || '👤'}
            </div>
          )}
          <h4 className="text-base font-bold text-white flex items-center gap-1.5">
            <span>{contact.name}</span>
            {contact.emoji && <span>{contact.emoji}</span>}
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">{contact.email}</p>
          <p className="text-xs text-slate-300 mt-2 italic px-4">"{contact.about || 'Available on ChatPro'}"</p>
        </div>

        <div className="p-3 rounded-xl bg-[#0a0d18] border border-slate-800 text-xs space-y-1.5">
          <div className="flex justify-between text-slate-400">
            <span>Total Messages Exchanged:</span>
            <span className="font-bold text-purple-300">{messageCount}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Encryption Status:</span>
            <span className="text-teal-400 font-semibold">End-to-End Encrypted</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onExportChat}
          className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-purple-600/20"
        >
          <Download className="w-4 h-4" />
          <span>Export Conversation Transcript</span>
        </button>
      </div>
    </div>
  );
};
