import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, CheckCircle, ShieldCheck, AlertCircle, Scan, Sparkles } from 'lucide-react';
import { DocumentType, IdentityDetails, UserProfile } from '../types';
import { performDocumentOcr } from '../services/ocr';
import confetti from 'canvas-confetti';

interface IdentityVerificationScreenProps {
  user: UserProfile;
  onVerificationComplete: (details: IdentityDetails, snapshotUrl: string) => void;
  onSkipForTesting?: () => void;
}

export const IdentityVerificationScreen: React.FC<IdentityVerificationScreenProps> = ({
  user,
  onVerificationComplete,
  onSkipForTesting
}) => {
  const [docType, setDocType] = useState<DocumentType>('nic');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [extractedData, setExtractedData] = useState<IdentityDetails | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Initialize camera stream
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: unknown) {
      console.warn('Camera access error:', err);
      setCameraError('Camera access denied or unavailable in this environment. You can use Simulated Document Capture below.');
    }
  };

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleCapture = async () => {
    let snapshot = '';
    if (videoRef.current && canvasRef.current && stream) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        snapshot = canvas.toDataURL('image/jpeg', 0.85);
      }
    } else {
      // Create a simulated document canvas image for environments without physical camera
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 400;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(0, 0, 640, 400);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(20, 20, 600, 360);
        ctx.strokeStyle = '#7c5cff';
        ctx.lineWidth = 4;
        ctx.strokeRect(30, 30, 580, 340);
        ctx.fillStyle = '#e2e8f0';
        ctx.font = 'bold 20px Inter, sans-serif';
        ctx.fillText('DEMOCRATIC SOCIALIST REPUBLIC OF SRI LANKA', 60, 80);
        ctx.font = '16px Inter, sans-serif';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText(`DOCUMENT TYPE: ${docType.toUpperCase()}`, 60, 130);
        ctx.fillText(`NUMBER: 199512345678`, 60, 170);
        ctx.fillText(`NAME: ${user.name.toUpperCase()}`, 60, 210);
        ctx.fillText(`DOB: 1995-05-15`, 60, 250);
      }
      snapshot = canvas.toDataURL('image/jpeg', 0.85);
    }

    setCapturedImage(snapshot);
    setIsProcessing(true);
    setScanProgress(15);

    // Simulate OCR stages
    const timer = setInterval(() => {
      setScanProgress((prev) => (prev < 90 ? prev + 25 : prev));
    }, 300);

    try {
      const details = await performDocumentOcr(snapshot, docType);
      clearInterval(timer);
      setScanProgress(100);
      setIsProcessing(false);
      setExtractedData(details);
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
      } catch {
        // ignore
      }
    } catch (e) {
      clearInterval(timer);
      setIsProcessing(false);
      console.error(e);
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    setExtractedData(null);
    setScanProgress(0);
    startCamera();
  };

  const handleConfirmAndProceed = () => {
    if (extractedData && capturedImage) {
      onVerificationComplete(extractedData, capturedImage);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#080b13] relative">
      <div className="w-full max-w-2xl bg-[#111625] border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8">
        {/* Step Banner */}
        <div className="flex items-center justify-between pb-5 border-b border-slate-800 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Identity Verification</h2>
              <p className="text-xs text-slate-400">Step 2: Capture government document to activate ChatPro</p>
            </div>
          </div>
          {onSkipForTesting && (
            <button
              onClick={onSkipForTesting}
              className="text-xs text-slate-400 hover:text-purple-300 underline cursor-pointer"
            >
              Skip verification (Demo)
            </button>
          )}
        </div>

        {/* Document Type Selector */}
        <div className="mb-5">
          <label className="block text-xs font-semibold text-slate-300 mb-2">Select Document Type:</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'nic', label: 'National ID / NIC' },
              { id: 'passport', label: 'Passport' },
              { id: 'driving_licence', label: 'Driving Licence' }
            ].map((type) => (
              <button
                key={type.id}
                type="button"
                onClick={() => setDocType(type.id as DocumentType)}
                className={`py-2.5 px-3 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                  docType === type.id
                    ? 'bg-purple-600/30 border-purple-500 text-purple-200 shadow-md shadow-purple-600/15'
                    : 'bg-[#0a0e1a] border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        {/* Camera / Image Container */}
        <div className="relative w-full aspect-video bg-[#090d16] rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center mb-5">
          {!capturedImage ? (
            <>
              {cameraError ? (
                <div className="p-6 text-center max-w-sm">
                  <AlertCircle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <p className="text-xs text-slate-300 mb-4">{cameraError}</p>
                  <button
                    type="button"
                    onClick={handleCapture}
                    className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white shadow cursor-pointer"
                  >
                    Simulate Camera Capture
                  </button>
                </div>
              ) : (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  {/* Guideline viewfinder overlay */}
                  <div className="absolute inset-8 border-2 border-dashed border-purple-400/50 rounded-lg pointer-events-none flex flex-col justify-between p-3">
                    <div className="flex justify-between items-center text-[10px] text-purple-300 bg-black/40 px-2 py-0.5 rounded backdrop-blur-sm self-start">
                      Align {docType.toUpperCase()} within frame
                    </div>
                    <div className="text-[10px] text-slate-300 bg-black/40 px-2 py-0.5 rounded backdrop-blur-sm self-center">
                      Ensure text and photo are well lit
                    </div>
                  </div>
                </>
              )}
            </>
          ) : (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={capturedImage}
                alt="Captured ID"
                className="w-full h-full object-contain bg-black"
              />
              {isProcessing && (
                <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center p-4">
                  <Scan className="w-10 h-10 text-purple-400 animate-pulse mb-3" />
                  <p className="text-sm font-semibold text-white mb-2">Extracting Document Data via OCR...</p>
                  <div className="w-48 bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-purple-500 to-teal-400 h-full transition-all duration-300"
                      style={{ width: `${scanProgress}%` }}
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-2">{scanProgress}% completed</span>
                </div>
              )}
            </div>
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Capture / Retake Controls */}
        {!extractedData && (
          <div className="flex items-center justify-center gap-3">
            {!capturedImage ? (
              <>
                <button
                  type="button"
                  onClick={handleCapture}
                  className="py-3 px-6 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-sm shadow-lg shadow-purple-600/30 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                >
                  <Camera className="w-4 h-4" />
                  <span>Capture Document</span>
                </button>
                <button
                  type="button"
                  onClick={startCamera}
                  className="py-3 px-4 rounded-xl bg-[#0a0e1a] border border-slate-700 text-slate-300 hover:text-white text-sm flex items-center gap-1.5 cursor-pointer"
                  title="Retry Camera"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Retry</span>
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={handleRetake}
                disabled={isProcessing}
                className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retake Photo</span>
              </button>
            )}
          </div>
        )}

        {/* Extracted Details Review */}
        {extractedData && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-3 duration-300">
            <div className="p-4 rounded-xl bg-[#0a0f1d] border border-teal-500/30">
              <div className="flex items-center gap-2 text-teal-400 font-semibold text-xs mb-3">
                <CheckCircle className="w-4 h-4" />
                <span>OCR Extracted Information</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Document Type</span>
                  <span className="text-slate-200 font-medium uppercase">{extractedData.documentType}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Document Number</span>
                  <span className="text-purple-300 font-mono font-bold">{extractedData.documentNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Full Name</span>
                  <span className="text-slate-200 font-medium">{extractedData.fullName}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Date of Birth</span>
                  <span className="text-slate-200 font-medium">{extractedData.dateOfBirth}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleRetake}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs cursor-pointer"
              >
                Scan Again
              </button>
              <button
                type="button"
                onClick={handleConfirmAndProceed}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-indigo-600 hover:from-teal-400 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg shadow-teal-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Confirm & Enter ChatPro</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
