import React, { useState } from 'react';
import {
  Shield,
  X,
  Users,
  MessageSquare,
  Radio,
  Download,
  Search,
  CheckCircle,
  FileText,
  AlertCircle,
  Send,
  Eye,
  RefreshCw,
  Clock
} from 'lucide-react';
import { UserProfile, ChatMessage } from '../types';

interface AdminCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  profiles: UserProfile[];
  allMessages: ChatMessage[];
  onSendBroadcast: (text: string) => void;
  onRefreshData: () => void;
}

export const AdminCenterModal: React.FC<AdminCenterModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  profiles,
  allMessages,
  onSendBroadcast,
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'broadcast' | 'monitor'>('dashboard');
  const [userSearch, setUserSearch] = useState('');
  const [broadcastText, setBroadcastText] = useState('');
  const [broadcastSent, setBroadcastSent] = useState(false);
  const [viewingDocUser, setViewingDocUser] = useState<UserProfile | null>(null);

  if (!isOpen) return null;

  // Stats
  const totalUsers = profiles.length;
  const verifiedNics = profiles.filter((p) => p.nicCaptured).length;
  const totalMessages = allMessages.length;
  const mediaMessages = allMessages.filter((m) => m.mediaUrl).length;

  const filteredUsers = profiles.filter((u) => {
    if (!userSearch) return true;
    const q = userSearch.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (u.nicNumber && u.nicNumber.toLowerCase().includes(q))
    );
  });

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastText.trim()) return;
    onSendBroadcast(broadcastText.trim());
    setBroadcastText('');
    setBroadcastSent(true);
    setTimeout(() => setBroadcastSent(false), 3500);
  };

  // CSV Export (Section 67)
  const handleExportCsv = () => {
    const headers = ['Name', 'Email', 'NIC', 'NIC Captured', 'Admin', 'Profile Setup', 'Created'];
    const rows = profiles.map((p) => [
      `"${p.name}"`,
      `"${p.email}"`,
      `"${p.nicNumber || 'N/A'}"`,
      p.nicCaptured ? 'Yes' : 'No',
      p.isAdmin ? 'Yes' : 'No',
      p.profileSetup ? 'Yes' : 'No',
      `"${p.createdAt || new Date().toISOString()}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ChatPro_Users_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-4xl bg-[#111625] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-[#0d1220]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center font-bold">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Admin Control Center</h2>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  Root Admin
                </span>
              </div>
              <p className="text-xs text-slate-400">Authenticated as {currentUser.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onRefreshData}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Refresh Telemetry"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-[#0a0d18] text-xs font-semibold px-4 overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Shield },
            { id: 'users', label: `Users (${totalUsers})`, icon: Users },
            { id: 'broadcast', label: 'Broadcast Message', icon: Radio },
            { id: 'monitor', label: `Messages (${totalMessages})`, icon: MessageSquare }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 cursor-pointer whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'border-teal-500 text-teal-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 custom-scrollbar">
          {/* TAB 1: Dashboard (Section 62) */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-xl bg-[#0a0f1e] border border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Registered Users</span>
                  <div className="text-2xl font-bold text-white mt-1">{totalUsers}</div>
                  <span className="text-[10px] text-teal-400 mt-1 block">Active Profiles</span>
                </div>

                <div className="p-4 rounded-xl bg-[#0a0f1e] border border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Verified NICs</span>
                  <div className="text-2xl font-bold text-purple-400 mt-1">{verifiedNics}</div>
                  <span className="text-[10px] text-purple-300 mt-1 block">
                    {Math.round((verifiedNics / totalUsers) * 100)}% Verified
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-[#0a0f1e] border border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Messages</span>
                  <div className="text-2xl font-bold text-teal-400 mt-1">{totalMessages}</div>
                  <span className="text-[10px] text-slate-400 mt-1 block">Realtime Messages</span>
                </div>

                <div className="p-4 rounded-xl bg-[#0a0f1e] border border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Media Messages</span>
                  <div className="text-2xl font-bold text-amber-400 mt-1">{mediaMessages}</div>
                  <span className="text-[10px] text-amber-300 mt-1 block">Photos, Videos, Audio</span>
                </div>
              </div>

              {/* Quick Actions & Security Banner */}
              <div className="p-4 rounded-xl bg-[#090d18] border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-teal-400" />
                    <span>User Data Export</span>
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Download complete user roster with NIC verification flags as CSV file.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md cursor-pointer shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Users CSV</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: User Directory (Section 63 & 64) */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="Search by name, email, or NIC..."
                    className="w-full pl-9 pr-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
              </div>

              <div className="space-y-2">
                {filteredUsers.map((user) => (
                  <div
                    key={user.id}
                    className="p-3.5 rounded-xl bg-[#0a0f1d] border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      {user.profilePhoto ? (
                        <img
                          src={user.profilePhoto}
                          alt={user.name}
                          className="w-10 h-10 rounded-xl object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-xl bg-purple-600/30 flex items-center justify-center text-lg">
                          {user.emoji || '👤'}
                        </div>
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{user.name}</span>
                          {user.isAdmin && (
                            <span className="text-[9px] bg-teal-500/20 text-teal-300 border border-teal-500/30 px-1.5 py-0.2 rounded font-bold">
                              ADMIN
                            </span>
                          )}
                          {user.nicCaptured ? (
                            <span className="text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.2 rounded font-semibold">
                              NIC Verified
                            </span>
                          ) : (
                            <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded">
                              Pending NIC
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">{user.email}</p>
                        {user.nicNumber && (
                          <p className="text-[10px] text-slate-500 font-mono">NIC: {user.nicNumber}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {user.nicPhotoUrl && (
                        <button
                          type="button"
                          onClick={() => setViewingDocUser(user)}
                          className="px-2.5 py-1.5 rounded-lg bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/40 text-purple-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View ID Document</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Admin Broadcast (Section 66) */}
          {activeTab === 'broadcast' && (
            <div className="space-y-4 max-w-lg mx-auto">
              <div className="p-4 rounded-xl bg-[#090d18] border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-teal-400 font-bold text-xs">
                  <Radio className="w-4 h-4" />
                  <span>Broadcast System Announcement</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Sends an official system broadcast message marked <code className="text-teal-300">is_broadcast = true</code> to all registered users simultaneously.
                </p>

                {broadcastSent && (
                  <div className="p-2.5 rounded-lg bg-teal-500/10 border border-teal-500/30 text-xs text-teal-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    <span>Broadcast successfully dispatched to {profiles.length - 1} recipients!</span>
                  </div>
                )}

                <form onSubmit={handleBroadcastSubmit} className="space-y-3">
                  <textarea
                    rows={4}
                    value={broadcastText}
                    onChange={(e) => setBroadcastText(e.target.value)}
                    placeholder="Enter announcement text to broadcast to all ChatPro users..."
                    className="w-full px-3 py-2 bg-[#121829] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-600/25 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Global Broadcast</span>
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 4: Messages Monitor (Section 65) */}
          {activeTab === 'monitor' && (
            <div className="space-y-3">
              <h4 className="text-xs font-semibold text-slate-400">Recent Realtime Messages Stream (Latest {allMessages.length})</h4>
              <div className="space-y-2">
                {[...allMessages].reverse().slice(0, 50).map((msg) => (
                  <div
                    key={msg.id}
                    className="p-3 rounded-xl bg-[#0a0f1d] border border-slate-800 text-xs flex items-start justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-purple-300">{msg.senderName}</span>
                        <span className="text-slate-500">➔</span>
                        <span className="font-bold text-teal-300">{msg.recipientName}</span>
                        {msg.isBroadcast && (
                          <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold">
                            BROADCAST
                          </span>
                        )}
                      </div>
                      <p className="text-slate-300 mt-1">
                        {msg.mediaType ? `[${msg.mediaType.toUpperCase()}]: ${msg.text || ''}` : msg.text}
                      </p>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono shrink-0">{msg.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Admin Identity Document Viewer Modal (Section 64) */}
      {viewingDocUser && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-60 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">Government Identity Document Review</h3>
                <p className="text-xs text-slate-400">
                  {viewingDocUser.name} • NIC: {viewingDocUser.nicNumber || '199512345678'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setViewingDocUser(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-2 rounded-xl bg-black border border-slate-800 flex items-center justify-center aspect-video overflow-hidden">
              <img
                src={viewingDocUser.nicPhotoUrl}
                alt="ID Document"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-3 rounded-xl bg-[#0a0f1e] border border-slate-800 text-xs space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Temporary Signed URL:</span>
                <span className="font-mono text-emerald-400">Expires in 5 minutes</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Storage Bucket:</span>
                <span className="font-mono text-purple-300">nic-images/{viewingDocUser.id}/</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Verification State:</span>
                <span className="text-teal-300 font-semibold">Legitimate / OCR Matched</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
