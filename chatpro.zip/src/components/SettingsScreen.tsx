import React, { useState } from 'react';
import {
  X,
  User,
  Shield,
  HardDrive,
  Trash2,
  Lock,
  Unlock,
  MessageSquare,
  Camera,
  CheckCircle,
  AlertTriangle,
  FileText
} from 'lucide-react';
import { UserProfile, ChatMessage } from '../types';
import { hashPasswordPBKDF2, verifyPasswordPBKDF2 } from '../services/storage';

interface SettingsScreenProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  allMessages: ChatMessage[];
  onUpdateProfile: (updated: UserProfile) => void;
  onClearMedia: () => number;
  onDeleteAccount: () => void;
}

const EMOJI_GRID = ['🇱🇰', '🛡️', '⚡', '✨', '🚀', '🔥', '💻', '💡', '😎', '🌟', '🎯', '🦁'];

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  isOpen,
  onClose,
  currentUser,
  allMessages,
  onUpdateProfile,
  onClearMedia,
  onDeleteAccount
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'privacy' | 'storage' | 'account'>('profile');

  // Profile fields
  const [name, setName] = useState(currentUser.name);
  const [about, setAbout] = useState(currentUser.about || '');
  const [emoji, setEmoji] = useState(currentUser.emoji || '🇱🇰');
  const [photoUrl, setPhotoUrl] = useState(currentUser.profilePhoto || '');

  // Privacy fields
  const [lockPassword, setLockPassword] = useState('');
  const [confirmLockPassword, setConfirmLockPassword] = useState('');
  const [lockStatusMessage, setLockStatusMessage] = useState('');
  const [autoReplyEnabled, setAutoReplyEnabled] = useState(currentUser.autoReplyEnabled);
  const [autoReplyText, setAutoReplyText] = useState(currentUser.autoReplyText || '');

  // Clear media confirmation stages
  const [clearStage, setClearStage] = useState<0 | 1 | 2>(0);
  const [clearedNotice, setClearedNotice] = useState('');

  // Delete account confirmation
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  if (!isOpen) return null;

  // Media statistics
  const userMediaMessages = allMessages.filter(
    (m) => (m.sender === currentUser.email || m.recipient === currentUser.email) && m.mediaUrl
  );
  const photoCount = userMediaMessages.filter((m) => m.mediaType === 'photo').length;
  const videoCount = userMediaMessages.filter((m) => m.mediaType === 'video').length;
  const voiceCount = userMediaMessages.filter((m) => m.mediaType === 'voice').length;
  const estimatedStorageMb = (photoCount * 1.8 + videoCount * 8.5 + voiceCount * 0.4).toFixed(1);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...currentUser,
      name: name.trim(),
      about: about.slice(0, 60),
      emoji,
      profilePhoto: photoUrl
    };
    onUpdateProfile(updated);
    alert('Profile updated successfully!');
  };

  const handleSetLockPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLockStatusMessage('');
    if (lockPassword.length < 4) {
      setLockStatusMessage('Password must be at least 4 characters');
      return;
    }
    if (lockPassword !== confirmLockPassword) {
      setLockStatusMessage('Passwords do not match');
      return;
    }

    const hash = await hashPasswordPBKDF2(lockPassword);
    const updated: UserProfile = {
      ...currentUser,
      lockPasswordHash: hash,
      contactListLocked: true
    };
    onUpdateProfile(updated);
    setLockPassword('');
    setConfirmLockPassword('');
    setLockStatusMessage('Privacy password set! Contact list is now locked.');
  };

  const handleDisableLock = () => {
    const updated: UserProfile = {
      ...currentUser,
      lockPasswordHash: undefined,
      contactListLocked: false
    };
    onUpdateProfile(updated);
    setLockStatusMessage('Privacy lock disabled.');
  };

  const handleSaveAutoReply = () => {
    const updated: UserProfile = {
      ...currentUser,
      autoReplyEnabled,
      autoReplyText
    };
    onUpdateProfile(updated);
    alert('Auto-reply settings saved!');
  };

  const handleClearMediaStep = () => {
    if (clearStage === 0) {
      setClearStage(1);
    } else if (clearStage === 1) {
      setClearStage(2);
    } else if (clearStage === 2) {
      const count = onClearMedia();
      setClearStage(0);
      setClearedNotice(`Cleared ${count} media files successfully.`);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-2xl bg-[#111625] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-[#0d1220]">
          <div>
            <h2 className="text-base font-bold text-white">ChatPro Settings</h2>
            <p className="text-xs text-slate-400">Manage profile, security locks, and cloud storage</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-[#0a0d18] text-xs font-semibold px-4 overflow-x-auto">
          {[
            { id: 'profile', label: 'Profile', icon: User },
            { id: 'privacy', label: 'Privacy & Automation', icon: Shield },
            { id: 'storage', label: 'Cloud Storage', icon: HardDrive },
            { id: 'account', label: 'Account', icon: Trash2 }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 cursor-pointer whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'border-purple-500 text-purple-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 custom-scrollbar">
          {/* TAB 1: Profile Customization (Section 26) */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 max-w-lg mx-auto">
              <div className="flex items-center gap-4 mb-4">
                <div className="relative">
                  {photoUrl ? (
                    <img
                      src={photoUrl}
                      alt="Avatar"
                      className="w-20 h-20 rounded-2xl object-cover ring-2 ring-purple-500/40"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-2xl bg-purple-600/30 flex items-center justify-center text-4xl border border-purple-500/30">
                      {emoji}
                    </div>
                  )}
                  <label className="absolute -bottom-1 -right-1 p-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white shadow-md cursor-pointer">
                    <Camera className="w-3.5 h-3.5" />
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setPhotoUrl(URL.createObjectURL(file));
                      }}
                    />
                  </label>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{currentUser.name}</h4>
                  <p className="text-xs text-slate-400">{currentUser.email}</p>
                  <span className="inline-block mt-1 text-[10px] font-semibold text-teal-400 bg-teal-950/40 border border-teal-800/40 px-2 py-0.5 rounded-full">
                    NIC Verified Citizen
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Display Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-slate-300">About (Status)</label>
                  <span className="text-[10px] text-slate-500">{about.length}/60 chars</span>
                </div>
                <input
                  type="text"
                  maxLength={60}
                  value={about}
                  onChange={(e) => setAbout(e.target.value)}
                  placeholder="e.g. Available on ChatPro..."
                  className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Profile Emoji</label>
                <div className="grid grid-cols-6 gap-2">
                  {EMOJI_GRID.map((e) => (
                    <button
                      key={e}
                      type="button"
                      onClick={() => setEmoji(e)}
                      className={`p-2 rounded-xl text-xl text-center border cursor-pointer ${
                        emoji === e
                          ? 'border-purple-500 bg-purple-600/30'
                          : 'border-slate-800 bg-[#0a0d18] hover:border-slate-700'
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/25 cursor-pointer"
              >
                Save Profile Changes
              </button>
            </form>
          )}

          {/* TAB 2: Privacy & Automation (Section 23 & 25) */}
          {activeTab === 'privacy' && (
            <div className="space-y-6 max-w-lg mx-auto">
              {/* Privacy Lock Section */}
              <div className="p-4 rounded-xl bg-[#090d18] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Contact List & Chat Lock (PBKDF2 SHA-256)</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Encrypted with 150,000 iterations for biometric-grade privacy.
                    </p>
                  </div>
                  {currentUser.lockPasswordHash ? (
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30 font-bold">
                      Active
                    </span>
                  ) : (
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
                      Disabled
                    </span>
                  )}
                </div>

                {lockStatusMessage && (
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300">
                    {lockStatusMessage}
                  </div>
                )}

                {!currentUser.lockPasswordHash ? (
                  <form onSubmit={handleSetLockPassword} className="space-y-2">
                    <input
                      type="password"
                      value={lockPassword}
                      onChange={(e) => setLockPassword(e.target.value)}
                      placeholder="Set Privacy Password"
                      className="w-full px-3 py-2 bg-[#121829] border border-slate-700 rounded-xl text-xs text-slate-200"
                    />
                    <input
                      type="password"
                      value={confirmLockPassword}
                      onChange={(e) => setConfirmLockPassword(e.target.value)}
                      placeholder="Confirm Privacy Password"
                      className="w-full px-3 py-2 bg-[#121829] border border-slate-700 rounded-xl text-xs text-slate-200"
                    />
                    <button
                      type="submit"
                      className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-black font-bold text-xs cursor-pointer"
                    >
                      Enable Privacy Password
                    </button>
                  </form>
                ) : (
                  <button
                    type="button"
                    onClick={handleDisableLock}
                    className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Remove Privacy Lock
                  </button>
                )}
              </div>

              {/* Auto-Reply Section (Section 25) */}
              <div className="p-4 rounded-xl bg-[#090d18] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                      <span>Smart Auto-Reply</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Automatically respond with a 5-minute per-sender cooldown.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoReplyEnabled}
                      onChange={(e) => setAutoReplyEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    Auto-Reply Message Text:
                  </label>
                  <textarea
                    rows={3}
                    value={autoReplyText}
                    onChange={(e) => setAutoReplyText(e.target.value)}
                    placeholder="e.g. Hi! I am currently away. I will respond to your message shortly."
                    className="w-full px-3 py-2 bg-[#121829] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleSaveAutoReply}
                  className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs cursor-pointer"
                >
                  Save Auto-Reply Settings
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: Cloud Storage Dashboard (Section 27 & 28) */}
          {activeTab === 'storage' && (
            <div className="space-y-5 max-w-lg mx-auto">
              <div className="p-4 rounded-xl bg-[#090d18] border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-5 h-5 text-teal-400" />
                    <div>
                      <h4 className="text-xs font-bold text-white">ChatPro Cloud Storage</h4>
                      <p className="text-[10px] text-slate-400">Supabase Storage Protocol</p>
                    </div>
                  </div>
                  <span className="text-sm font-bold font-mono text-teal-300">
                    {estimatedStorageMb} MB Used
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center mb-4">
                  <div className="p-2.5 rounded-lg bg-[#121829] border border-slate-800">
                    <span className="text-lg font-bold text-purple-400 block">{photoCount}</span>
                    <span className="text-[10px] text-slate-400">Photos</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#121829] border border-slate-800">
                    <span className="text-lg font-bold text-teal-400 block">{videoCount}</span>
                    <span className="text-[10px] text-slate-400">Videos</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#121829] border border-slate-800">
                    <span className="text-lg font-bold text-indigo-400 block">{voiceCount}</span>
                    <span className="text-[10px] text-slate-400">Voice Notes</span>
                  </div>
                </div>

                {clearedNotice && (
                  <div className="p-2 mb-3 rounded-lg bg-teal-500/10 border border-teal-500/30 text-xs text-teal-300 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" /> {clearedNotice}
                  </div>
                )}

                {/* Clear Media with two confirmations (Section 29) */}
                <div className="border-t border-slate-800 pt-3">
                  {clearStage === 0 && (
                    <button
                      type="button"
                      onClick={handleClearMediaStep}
                      className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Clear Media Cache</span>
                    </button>
                  )}

                  {clearStage === 1 && (
                    <div className="space-y-2 text-center p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
                      <p className="text-xs text-amber-300 font-semibold">
                        Confirm 1 of 2: Are you sure you want to delete all cached media?
                      </p>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setClearStage(0)}
                          className="flex-1 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={handleClearMediaStep}
                          className="flex-1 py-1.5 rounded-lg bg-amber-600 text-xs text-black font-bold"
                        >
                          Yes, Proceed
                        </button>
                      </div>
                    </div>
                  )}

                  {clearStage === 2 && (
                    <div className="space-y-2 text-center p-3 rounded-xl bg-rose-500/10 border border-rose-500/30">
                      <p className="text-xs text-rose-300 font-semibold">
                        Confirm 2 of 2: This action is permanent and cannot be undone!
                      </p>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setClearStage(0)}
                          className="flex-1 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300"
                        >
                          Abort
                        </button>
                        <button
                          type="button"
                          onClick={handleClearMediaStep}
                          className="flex-1 py-1.5 rounded-lg bg-rose-600 text-xs text-white font-bold"
                        >
                          Permanently Clear Media
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Account Deletion (Section 30) */}
          {activeTab === 'account' && (
            <div className="space-y-4 max-w-lg mx-auto">
              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 space-y-3">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Delete ChatPro Account</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Executing account deletion invokes <code className="text-rose-300">delete_my_account</code>. All
                  messages, contact connections, stored identity documents, and media records will be permanently purged.
                </p>

                {!showDeleteConfirm ? (
                  <button
                    type="button"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="py-2.5 px-4 rounded-xl bg-rose-600/30 hover:bg-rose-600 text-rose-200 hover:text-white border border-rose-500/40 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    Initiate Account Deletion
                  </button>
                ) : (
                  <div className="p-3 bg-black/40 rounded-xl space-y-2">
                    <p className="text-xs text-rose-400 font-bold">
                      Are you absolutely sure you want to permanently delete your account?
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setShowDeleteConfirm(false)}
                        className="flex-1 py-2 rounded-lg bg-slate-800 text-xs text-slate-300 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={onDeleteAccount}
                        className="flex-1 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
                      >
                        Yes, Delete My Account
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
