import React, { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff, Maximize2, Shield } from 'lucide-react';
import { ActiveCall } from '../types';

interface CallModalProps {
  call: ActiveCall;
  onAnswer: () => void;
  onDecline: () => void;
  onHangup: () => void;
  onToggleMute: () => void;
  onToggleVideo: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  call,
  onAnswer,
  onDecline,
  onHangup,
  onToggleMute,
  onToggleVideo
}) => {
  const [duration, setDuration] = useState(0);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);

  // Call timer
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (call.status === 'connected') {
      timer = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [call.status]);

  // Video streams
  useEffect(() => {
    let currentStream: MediaStream | null = null;
    if (call.active && call.type === 'video' && call.status === 'connected') {
      navigator.mediaDevices
        ?.getUserMedia({ video: true, audio: true })
        .then((s) => {
          currentStream = s;
          setLocalStream(s);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = s;
          }
        })
        .catch((err) => {
          console.warn('Camera access error during call:', err);
        });
    }

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [call.active, call.type, call.status]);

  if (!call.active) return null;

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  // 1. Incoming Call Screen
  if (call.status === 'incoming') {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
        <div className="w-full max-w-sm bg-[#121829] border border-purple-500/40 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center animate-bounce-slow">
          <div className="relative mb-4">
            <div className="w-20 h-20 rounded-2xl bg-purple-600/30 border border-purple-500/40 p-1 flex items-center justify-center">
              {call.contact.profilePhoto ? (
                <img
                  src={call.contact.profilePhoto}
                  alt={call.contact.name}
                  className="w-full h-full rounded-xl object-cover"
                />
              ) : (
                <span className="text-3xl">{call.contact.emoji || '👤'}</span>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-teal-500 flex items-center justify-center text-white ring-2 ring-[#121829]">
              {call.type === 'video' ? <Video className="w-3 h-3" /> : <Phone className="w-3 h-3" />}
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mb-1">{call.contact.name}</h3>
          <p className="text-xs text-purple-300 mb-6">
            Incoming {call.type === 'video' ? 'Video' : 'Voice'} Call (ChatPro WebRTC)...
          </p>

          <div className="flex items-center gap-6 w-full justify-center">
            <button
              type="button"
              onClick={onDecline}
              className="w-14 h-14 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white flex flex-col items-center justify-center shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
            >
              <PhoneOff className="w-6 h-6" />
              <span className="text-[9px] mt-0.5 font-bold">Decline</span>
            </button>

            <button
              type="button"
              onClick={onAnswer}
              className="w-14 h-14 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white flex flex-col items-center justify-center shadow-lg shadow-emerald-600/30 animate-pulse transition-all cursor-pointer"
            >
              <Phone className="w-6 h-6" />
              <span className="text-[9px] mt-0.5 font-bold">Answer</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Active Connected / Calling Call Screen
  return (
    <div className="fixed inset-0 bg-[#070a12]/95 backdrop-blur-xl z-50 flex flex-col items-center justify-between p-4 sm:p-8">
      {/* Header bar */}
      <div className="w-full max-w-4xl flex items-center justify-between z-10">
        <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/60 px-3 py-1.5 rounded-full border border-slate-800">
          <Shield className="w-3.5 h-3.5 text-purple-400" />
          <span>STUN: stun.l.google.com:19302 (WebRTC P2P)</span>
        </div>
        <div className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-full border border-emerald-800/40">
          {call.status === 'connected' ? `Connected • ${formatDuration(duration)}` : 'Calling...'}
        </div>
      </div>

      {/* Main View Area */}
      <div className="w-full max-w-4xl flex-1 flex items-center justify-center relative my-4 rounded-3xl overflow-hidden bg-[#0c101d] border border-slate-800 shadow-2xl">
        {call.type === 'video' ? (
          <div className="w-full h-full relative flex items-center justify-center bg-black">
            {/* Simulated Remote Video */}
            <div className="w-full h-full flex flex-col items-center justify-center relative">
              {call.contact.profilePhoto ? (
                <img
                  src={call.contact.profilePhoto}
                  alt={call.contact.name}
                  className="w-36 h-36 rounded-full object-cover shadow-2xl ring-4 ring-purple-500/40"
                />
              ) : (
                <div className="w-36 h-36 rounded-full bg-purple-600/30 flex items-center justify-center text-5xl">
                  {call.contact.emoji || '👤'}
                </div>
              )}
              <h2 className="text-lg font-bold text-white mt-4">{call.contact.name}</h2>
              <p className="text-xs text-slate-400 mt-1">Remote WebRTC Video Stream</p>
            </div>

            {/* Local Video Inset */}
            <div className="absolute top-4 right-4 w-36 sm:w-48 aspect-video rounded-2xl overflow-hidden bg-slate-900 border-2 border-purple-500/50 shadow-2xl">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 right-2 text-[9px] bg-black/60 px-1.5 rounded text-white font-mono">
                You
              </span>
            </div>
          </div>
        ) : (
          /* Voice Call Avatar */
          <div className="flex flex-col items-center justify-center text-center p-6">
            <div className="relative mb-6">
              <div className="w-32 h-32 rounded-3xl bg-purple-600/20 border-2 border-purple-500/40 p-2 flex items-center justify-center shadow-2xl">
                {call.contact.profilePhoto ? (
                  <img
                    src={call.contact.profilePhoto}
                    alt={call.contact.name}
                    className="w-full h-full rounded-2xl object-cover"
                  />
                ) : (
                  <span className="text-5xl">{call.contact.emoji || '👤'}</span>
                )}
              </div>
              <div className="absolute inset-0 rounded-3xl border-2 border-purple-400/40 animate-ping pointer-events-none" />
            </div>

            <h2 className="text-xl font-bold text-white mb-1">{call.contact.name}</h2>
            <p className="text-xs text-slate-400 mb-2">{call.contact.email}</p>
            <span className="text-sm font-mono text-purple-300">
              {call.status === 'connected' ? formatDuration(duration) : 'Ringing...'}
            </span>
          </div>
        )}
      </div>

      {/* Control Buttons */}
      <div className="flex items-center gap-4 bg-[#111625] px-6 py-3 rounded-2xl border border-slate-800 shadow-xl z-10">
        <button
          type="button"
          onClick={onToggleMute}
          className={`p-3.5 rounded-xl text-white transition-colors cursor-pointer ${
            call.isMuted ? 'bg-amber-600 hover:bg-amber-500' : 'bg-slate-800 hover:bg-slate-700'
          }`}
          title={call.isMuted ? 'Unmute microphone' : 'Mute microphone'}
        >
          {call.isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {call.type === 'video' && (
          <button
            type="button"
            onClick={onToggleVideo}
            className={`p-3.5 rounded-xl text-white transition-colors cursor-pointer ${
              call.isVideoOff ? 'bg-amber-600 hover:bg-amber-500' : 'bg-slate-800 hover:bg-slate-700'
            }`}
            title={call.isVideoOff ? 'Turn on camera' : 'Turn off camera'}
          >
            {call.isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>
        )}

        <button
          type="button"
          onClick={onHangup}
          className="px-6 py-3.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold flex items-center gap-2 shadow-lg shadow-rose-600/30 transition-all cursor-pointer active:scale-95"
          title="End Call"
        >
          <PhoneOff className="w-5 h-5" />
          <span className="text-xs font-bold">End Call</span>
        </button>
      </div>
    </div>
  );
};
