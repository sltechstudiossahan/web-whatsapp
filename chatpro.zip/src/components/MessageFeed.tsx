import React, { useState, useRef, useEffect } from 'react';
import {
  Check,
  CheckCheck,
  Play,
  Pause,
  MapPin,
  Clock,
  Star,
  Pin,
  Copy,
  Volume2,
  Trash2,
  Share2,
  Globe,
  Bell,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { ChatMessage, UserProfile } from '../types';
import { isSinhalaText } from '../services/sinhala';
import { readAloudText } from '../services/voice';

interface MessageFeedProps {
  messages: ChatMessage[];
  currentUser: UserProfile;
  starredIds: string[];
  pinnedIds: string[];
  onToggleStar: (messageId: string) => void;
  onTogglePin: (messageId: string) => void;
  onDeleteMessage: (messageId: string) => void;
  onForwardMessage: (message: ChatMessage) => void;
  onReplyMessage: (message: ChatMessage) => void;
  onTranslateMessage: (message: ChatMessage) => void;
  onRemindMessage: (message: ChatMessage) => void;
  onVotePoll: (messageId: string, optionId: string) => void;
  onOpenMediaLightbox: (mediaUrl: string, type: 'photo' | 'video') => void;
  searchQuery?: string;
}

export const MessageFeed: React.FC<MessageFeedProps> = ({
  messages,
  currentUser,
  starredIds,
  pinnedIds,
  onToggleStar,
  onTogglePin,
  onDeleteMessage,
  onForwardMessage,
  onReplyMessage,
  onTranslateMessage,
  onRemindMessage,
  onVotePoll,
  onOpenMediaLightbox,
  searchQuery = ''
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [activeVoicePlayingId, setActiveVoicePlayingId] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Context menu state
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    message: ChatMessage | null;
  }>({
    visible: false,
    x: 0,
    y: 0,
    message: null
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Handle Voice Playback
  const handlePlayVoice = (msg: ChatMessage) => {
    if (!msg.mediaUrl) return;

    if (activeVoicePlayingId === msg.id) {
      audioPlayerRef.current?.pause();
      setActiveVoicePlayingId(null);
      return;
    }

    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }

    const audio = new Audio(msg.mediaUrl);
    audioPlayerRef.current = audio;
    setActiveVoicePlayingId(msg.id);

    audio.onended = () => {
      setActiveVoicePlayingId(null);
    };
    audio.onerror = () => {
      setActiveVoicePlayingId(null);
    };

    audio.play().catch(() => {
      setActiveVoicePlayingId(null);
    });
  };

  const handleContextMenu = (e: React.MouseEvent, message: ChatMessage) => {
    e.preventDefault();
    setContextMenu({
      visible: true,
      x: Math.min(e.clientX, window.innerWidth - 200),
      y: Math.min(e.clientY, window.innerHeight - 300),
      message
    });
  };

  const closeContextMenu = () => {
    setContextMenu({ visible: false, x: 0, y: 0, message: null });
  };

  useEffect(() => {
    const handleGlobalClick = () => {
      if (contextMenu.visible) closeContextMenu();
    };
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [contextMenu.visible]);

  return (
    <div
      className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#090d18] bg-[radial-gradient(#182038_1px,transparent_1px)] [background-size:24px_24px] custom-scrollbar relative"
    >
      {messages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 py-12">
          <Sparkles className="w-8 h-8 text-purple-400 mb-2 opacity-60" />
          <p className="text-xs font-semibold text-slate-300">End-to-End Encrypted Chat</p>
          <p className="text-[11px] text-slate-500 mt-1 max-w-xs">
            Messages are encrypted. Send text, voice notes, photos, videos, polls, or ask ChatPro AI.
          </p>
        </div>
      ) : (
        messages.map((msg) => {
          const isMe = msg.sender.toLowerCase() === currentUser.email.toLowerCase();
          const isSinhala = msg.language === 'si' || isSinhalaText(msg.text);
          const isStarred = starredIds.includes(msg.id);
          const isPinned = pinnedIds.includes(msg.id);
          const isVoicePlaying = activeVoicePlayingId === msg.id;

          const matchesSearch = searchQuery && msg.text.toLowerCase().includes(searchQuery.toLowerCase());

          return (
            <div
              key={msg.id}
              onContextMenu={(e) => handleContextMenu(e, msg)}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group transition-all`}
            >
              {/* Message Bubble Container */}
              <div
                className={`relative max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-lg transition-all ${
                  isMe
                    ? 'bg-gradient-to-tr from-purple-700 to-indigo-600 text-white rounded-tr-none'
                    : 'bg-[#141b2d] border border-slate-800 text-slate-100 rounded-tl-none'
                } ${matchesSearch ? 'ring-2 ring-amber-400' : ''}`}
              >
                {/* Reply To Preview (if present) */}
                {msg.metadata?.replyToText && (
                  <div
                    className={`mb-2 p-2 rounded-lg text-[11px] border-l-2 ${
                      isMe ? 'bg-purple-950/40 border-purple-300 text-purple-200' : 'bg-slate-900 border-teal-400 text-slate-300'
                    }`}
                  >
                    <span className="font-bold block text-[10px] opacity-80">
                      {msg.metadata.replyToSender || 'Replied message'}
                    </span>
                    <p className="truncate">{msg.metadata.replyToText}</p>
                  </div>
                )}

                {/* Forwarded Tag */}
                {msg.metadata?.forwardedFrom && (
                  <span className="text-[10px] italic text-slate-400 flex items-center gap-1 mb-1">
                    <Share2 className="w-2.5 h-2.5" /> Forwarded
                  </span>
                )}

                {/* Photo Message */}
                {msg.mediaType === 'photo' && msg.mediaUrl && (
                  <div className="mb-2 rounded-xl overflow-hidden cursor-pointer">
                    <img
                      src={msg.mediaUrl}
                      alt="Shared photo"
                      onClick={() => onOpenMediaLightbox(msg.mediaUrl!, 'photo')}
                      className="w-full max-h-72 object-cover hover:opacity-95 transition-opacity"
                    />
                  </div>
                )}

                {/* Video Message */}
                {msg.mediaType === 'video' && msg.mediaUrl && (
                  <div className="mb-2 rounded-xl overflow-hidden">
                    <video
                      src={msg.mediaUrl}
                      controls
                      className="w-full max-h-72 rounded-xl bg-black"
                    />
                  </div>
                )}

                {/* Voice Message */}
                {msg.mediaType === 'voice' && (
                  <div className="flex items-center gap-3 py-1 pr-2 min-w-[200px]">
                    <button
                      type="button"
                      onClick={() => handlePlayVoice(msg)}
                      className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 cursor-pointer shadow ${
                        isMe ? 'bg-white text-purple-700' : 'bg-purple-600 text-white'
                      }`}
                    >
                      {isVoicePlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>

                    {/* Animated Audio Waveform */}
                    <div className="flex-1 flex items-center gap-0.5 h-6">
                      {[40, 75, 50, 90, 60, 80, 45, 100, 70, 85, 30, 65, 95, 45, 60].map((h, i) => (
                        <span
                          key={i}
                          className={`w-1 rounded-full transition-all duration-200 ${
                            isMe ? 'bg-purple-200' : 'bg-teal-400'
                          } ${isVoicePlaying ? 'animate-pulse' : 'opacity-70'}`}
                          style={{ height: `${h}%` }}
                        />
                      ))}
                    </div>

                    <span className="text-[10px] font-mono opacity-80 shrink-0">
                      0:{String(msg.duration || 12).padStart(2, '0')}
                    </span >
                  </div>
                )}

                {/* Location Message */}
                {msg.messageType === 'location' && msg.metadata?.location && (
                  <div className="mb-2 p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-teal-400 text-xs font-semibold">
                      <MapPin className="w-4 h-4 shrink-0" />
                      <span>Live Shared Location</span>
                    </div>
                    <p className="text-[11px] font-mono text-slate-300">
                      Lat: {msg.metadata.location.latitude.toFixed(5)}, Lng: {msg.metadata.location.longitude.toFixed(5)}
                    </p>
                    <a
                      href={msg.metadata.location.mapUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs text-purple-300 hover:text-purple-200 underline font-medium"
                    >
                      <span>Open in Google Maps</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}

                {/* Poll Message */}
                {msg.messageType === 'poll' && msg.metadata?.poll && (
                  <div className="mb-2 p-3.5 rounded-xl bg-slate-900/80 border border-slate-700/70 space-y-3 min-w-[240px]">
                    <p className="text-xs font-bold text-white leading-snug">
                      📊 {msg.metadata.poll.question}
                    </p>
                    <div className="space-y-2">
                      {msg.metadata.poll.options.map((opt) => {
                        const total = msg.metadata?.poll?.totalVotes || 1;
                        const votesCount = opt.votes?.length || 0;
                        const pct = Math.round((votesCount / (total || 1)) * 100);
                        const hasVoted = opt.votes?.includes(currentUser.email);

                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => onVotePoll(msg.id, opt.id)}
                            className={`w-full text-left p-2.5 rounded-lg border relative overflow-hidden transition-all cursor-pointer ${
                              hasVoted
                                ? 'border-teal-500 bg-teal-950/20 text-teal-200'
                                : 'border-slate-700 bg-slate-800/60 text-slate-200 hover:border-slate-600'
                            }`}
                          >
                            <div
                              className="absolute left-0 top-0 bottom-0 bg-teal-500/20 transition-all duration-500 pointer-events-none"
                              style={{ width: `${pct}%` }}
                            />
                            <div className="relative z-10 flex items-center justify-between text-xs">
                              <span className="font-medium truncate pr-2">{opt.text}</span>
                              <span className="text-[11px] font-mono text-slate-300 shrink-0">
                                {votesCount} ({pct}%)
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    <span className="text-[10px] text-slate-400 block text-right">
                      {msg.metadata.poll.totalVotes} total votes
                    </span>
                  </div>
                )}

                {/* Sticker Message */}
                {msg.messageType === 'sticker' && (
                  <div className="text-5xl py-1 select-none animate-bounce">
                    {msg.text}
                  </div>
                )}

                {/* Text Content */}
                {msg.text && msg.messageType !== 'sticker' && (
                  <p
                    className={`text-xs sm:text-sm leading-relaxed break-words ${
                      isSinhala ? 'font-[\'Noto_Sans_Sinhala\'] font-medium' : 'font-sans'
                    }`}
                  >
                    {msg.text}
                  </p>
                )}

                {/* Footer Metadata (Language badge, Timestamp, Status ticks, Star/Pin) */}
                <div className="flex items-center justify-end gap-1.5 mt-1.5 text-[10px] opacity-80 select-none">
                  {/* Language detection badge (Section 14) */}
                  <span
                    className={`px-1 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider ${
                      isSinhala
                        ? 'bg-amber-400 text-black'
                        : isMe
                        ? 'bg-purple-900/60 text-purple-200'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                    title={isSinhala ? 'Sinhala language detected' : 'English text'}
                  >
                    {isSinhala ? 'සිං' : 'EN'}
                  </span>

                  {isPinned && <Pin className="w-2.5 h-2.5 text-amber-300" />}
                  {isStarred && <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />}

                  {msg.status === 'scheduled' ? (
                    <span className="flex items-center gap-0.5 text-indigo-300">
                      <Clock className="w-2.5 h-2.5" /> Scheduled
                    </span>
                  ) : (
                    <span>{msg.timestamp}</span>
                  )}

                  {isMe && (
                    <span className="ml-0.5">
                      {msg.status === 'read' ? (
                        <CheckCheck className="w-3.5 h-3.5 text-teal-300" />
                      ) : msg.status === 'delivered' ? (
                        <CheckCheck className="w-3.5 h-3.5 text-slate-300" />
                      ) : (
                        <Check className="w-3.5 h-3.5 text-slate-300" />
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })
      )}
      <div ref={bottomRef} />

      {/* Message Context Menu (Right Click / Long Press) - Section 52 */}
      {contextMenu.visible && contextMenu.message && (
        <div
          className="fixed bg-[#121829] border border-slate-700/80 rounded-xl shadow-2xl p-1 z-50 text-xs w-48 space-y-0.5 animate-in fade-in zoom-in-95 duration-100"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            type="button"
            onClick={() => {
              onReplyMessage(contextMenu.message!);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-purple-400" />
            <span>Reply</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (contextMenu.message?.text) {
                navigator.clipboard.writeText(contextMenu.message.text);
              }
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5 text-slate-400" />
            <span>Copy text</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onToggleStar(contextMenu.message!.id);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Star className="w-3.5 h-3.5 text-amber-400" />
            <span>{starredIds.includes(contextMenu.message.id) ? 'Unstar' : 'Star message'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onTogglePin(contextMenu.message!.id);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Pin className="w-3.5 h-3.5 text-indigo-400" />
            <span>{pinnedIds.includes(contextMenu.message.id) ? 'Unpin' : 'Pin message'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onTranslateMessage(contextMenu.message!);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-teal-400" />
            <span>Translate (EN/සිං)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onRemindMessage(contextMenu.message!);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span>Remind me</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onForwardMessage(contextMenu.message!);
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-sky-400" />
            <span>Forward</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (contextMenu.message?.text) {
                readAloudText(contextMenu.message.text);
              }
              closeContextMenu();
            }}
            className="w-full px-2.5 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Read aloud</span>
          </button>

          {contextMenu.message.sender.toLowerCase() === currentUser.email.toLowerCase() && (
            <>
              <div className="border-t border-slate-800 my-0.5" />
              <button
                type="button"
                onClick={() => {
                  onDeleteMessage(contextMenu.message!.id);
                  closeContextMenu();
                }}
                className="w-full px-2.5 py-1.5 rounded-lg text-left text-rose-400 hover:bg-rose-950/40 flex items-center gap-2 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete for me</span>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};
