import React, { useState } from 'react';
import { Shield, Sparkles, User, Lock, Mail, ArrowRight, CheckCircle2 } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthScreenProps {
  onLogin: (email: string) => void;
  onSignUp: (email: string, name: string) => void;
  existingProfiles: UserProfile[];
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, onSignUp, existingProfiles }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('admin1@chatapp.com');
  const [password, setPassword] = useState('admin123');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    if (isSignUp) {
      if (!name.trim()) {
        setError('Please enter your display name');
        return;
      }
      onSignUp(email.trim().toLowerCase(), name.trim());
      setSuccess('Account created! Initializing identity verification...');
    } else {
      const found = existingProfiles.find((p) => p.email.toLowerCase() === email.trim().toLowerCase());
      if (found) {
        onLogin(found.email);
      } else {
        // Auto-provision or register
        onSignUp(email.trim().toLowerCase(), email.split('@')[0]);
      }
    }
  };

  const selectDemoAccount = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setIsSignUp(false);
    setError('');
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#080b13] relative overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-[#111625]/90 border border-slate-800 backdrop-blur-xl rounded-2xl shadow-2xl p-6 sm:p-8 z-10 transition-all">
        {/* Brand Header */}
        <div className="flex flex-col items-center mb-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-teal-400 p-0.5 shadow-lg shadow-purple-500/20 mb-3 flex items-center justify-center">
            <div className="w-full h-full bg-[#0d121f] rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-7 h-7 text-purple-400" />
            </div>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Chat<span className="text-purple-400">Pro</span>
            <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
              v2.0
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">Next-Gen Realtime Messenger Platform</p>
        </div>

        {/* Tab switch */}
        <div className="flex rounded-xl bg-[#0a0e1a] p-1 mb-6 border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setIsSignUp(false);
              setError('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              !isSignUp ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setIsSignUp(true);
              setError('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              isSignUp ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Create Account
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
            <span>•</span> {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 rounded-lg bg-teal-500/10 border border-teal-500/30 text-xs text-teal-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" /> {success}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Kasun Perera"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#0a0d18] border border-slate-700/80 rounded-xl text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@chatapp.com"
                className="w-full pl-9 pr-3 py-2.5 bg-[#0a0d18] border border-slate-700/80 rounded-xl text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 bg-[#0a0d18] border border-slate-700/80 rounded-xl text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-sm shadow-lg shadow-purple-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99]"
          >
            <span>{isSignUp ? 'Continue to Identity Verification' : 'Sign In to ChatPro'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Demo Fast-Switch Section */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2.5 text-center">
            Quick Demo Accounts
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => selectDemoAccount('admin1@chatapp.com', 'admin123')}
              className="p-2 rounded-lg bg-purple-950/30 hover:bg-purple-900/40 border border-purple-800/40 text-left transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-1.5 text-xs font-medium text-purple-300">
                <Shield className="w-3.5 h-3.5 text-purple-400" />
                <span>Admin Kasun</span>
              </div>
              <p className="text-[10px] text-slate-400 truncate">admin1@chatapp.com</p>
            </button>

            <button
              type="button"
              onClick={() => selectDemoAccount('user1@chatapp.com', 'user123')}
              className="p-2 rounded-lg bg-teal-950/30 hover:bg-teal-900/40 border border-teal-800/40 text-left transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-1.5 text-xs font-medium text-teal-300">
                <User className="w-3.5 h-3.5 text-teal-400" />
                <span>Kasun (User)</span>
              </div>
              <p className="text-[10px] text-slate-400 truncate">user1@chatapp.com</p>
            </button>
          </div>

          <div className="mt-2 text-center">
            <button
              type="button"
              onClick={() => {
                const rand = Math.floor(100 + Math.random() * 900);
                setEmail(`citizen${rand}@chatapp.com`);
                setName(`New Citizen ${rand}`);
                setPassword('securepass');
                setIsSignUp(true);
              }}
              className="text-[11px] text-slate-400 hover:text-purple-300 underline transition-colors cursor-pointer"
            >
              Test Identity Verification Flow (New Unverified User)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
