import React, { useState } from 'react';
import {
  Sparkles,
  Shield,
  Palette,
  Settings as SettingsIcon,
  LogOut,
  Circle
} from 'lucide-react';
import { UserProfile, PresenceStatus, ThemePreset } from '../types';

interface NavbarProps {
  currentUser: UserProfile;
  onOpenSettings: () => void;
  onOpenAdmin: () => void;
  onToggleAI: () => void;
  isAIOpen: boolean;
  onLogout: () => void;
  onUpdatePresence: (status: PresenceStatus) => void;
  activeTheme: ThemePreset;
  onSelectTheme: (theme: ThemePreset) => void;
}

const PRESENCE_OPTIONS: { status: PresenceStatus; label: string; color: string }[] = [
  { status: 'available', label: 'Available', color: 'bg-emerald-500' },
  { status: 'busy', label: 'Busy', color: 'bg-red-500' },
  { status: 'working', label: 'Working', color: 'bg-amber-500' },
  { status: 'studying', label: 'Studying', color: 'bg-blue-500' },
  { status: 'listening to music', label: 'Listening to music', color: 'bg-purple-500' },
  { status: 'focus mode', label: 'Focus mode', color: 'bg-indigo-500' },
  { status: 'do not disturb', label: 'Do not disturb', color: 'bg-rose-500' },
  { status: 'offline', label: 'Appear Offline', color: 'bg-slate-500' }
];

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenSettings,
  onOpenAdmin,
  onToggleAI,
  isAIOpen,
  onLogout,
  onUpdatePresence,
  activeTheme,
  onSelectTheme
}) => {
  const [showPresenceMenu, setShowPresenceMenu] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  const currentPresence = PRESENCE_OPTIONS.find((p) => p.status === currentUser.presenceState) || PRESENCE_OPTIONS[0];

  return (
    <header className="h-16 px-4 sm:px-6 bg-[#0c101d]/95 border-b border-slate-800/80 backdrop-blur-md flex items-center justify-between z-30 shrink-0 select-none">
      {/* Left: Brand */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-teal-400 p-0.5 shadow-md shadow-purple-600/20 flex items-center justify-center">
          <div className="w-full h-full bg-[#0a0e1a] rounded-[10px] flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-purple-400" />
          </div>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-base tracking-tight text-white">
              Chat<span className="text-purple-400">Pro</span>
            </span>
            <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Live
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">Next-Gen Realtime Messenger</p>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* ChatPro AI Button */}
        <button
          type="button"
          onClick={onToggleAI}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
            isAIOpen
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/25 ring-2 ring-purple-400/30'
              : 'bg-purple-950/40 text-purple-300 hover:bg-purple-900/50 border border-purple-800/40'
          }`}
        >
          <Sparkles className={`w-3.5 h-3.5 ${isAIOpen ? 'text-white' : 'text-purple-400'}`} />
          <span>ChatPro AI</span>
        </button>

        {/* Admin Control Center (for admins or toggle) */}
        {currentUser.isAdmin && (
          <button
            type="button"
            onClick={onOpenAdmin}
            className="px-3 py-1.5 rounded-xl bg-teal-950/40 hover:bg-teal-900/50 border border-teal-800/40 text-teal-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Shield className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">Admin Center</span>
          </button>
        )}

        {/* Theme Selector */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setShowThemeMenu(!showThemeMenu);
              setShowPresenceMenu(false);
            }}
            className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/60 text-slate-300 text-xs flex items-center cursor-pointer transition-colors"
            title="Switch Theme"
          >
            <Palette className="w-4 h-4 text-purple-400" />
          </button>

          {showThemeMenu && (
            <div className="absolute right-0 top-12 w-48 bg-[#111728] border border-slate-700 rounded-xl shadow-2xl p-2 z-50 text-xs space-y-1">
              <span className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Chat Themes
              </span>
              {[
                { id: 'cyberpunk', name: 'Cyberpunk Neon', color: '#7c5cff' },
                { id: 'neon-purple', name: 'Ultra Purple', color: '#9333ea' },
                { id: 'emerald', name: 'Emerald Matrix', color: '#10b981' },
                { id: 'crimson', name: 'Crimson Ember', color: '#ef4444' },
                { id: 'midnight-gold', name: 'Midnight Gold', color: '#f59e0b' }
              ].map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => {
                    onSelectTheme(theme.id as ThemePreset);
                    setShowThemeMenu(false);
                  }}
                  className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center justify-between cursor-pointer ${
                    activeTheme === theme.id ? 'bg-purple-600/30 text-white font-medium' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: theme.color }} />
                    <span>{theme.name}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Presence & Profile Button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setShowPresenceMenu(!showPresenceMenu);
              setShowThemeMenu(false);
            }}
            className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/60 cursor-pointer transition-colors"
          >
            <div className="relative">
              {currentUser.profilePhoto ? (
                <img
                  src={currentUser.profilePhoto}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-lg object-cover"
                />
              ) : (
                <div className="w-7 h-7 rounded-lg bg-purple-600/30 flex items-center justify-center text-xs">
                  {currentUser.emoji || '👤'}
                </div>
              )}
              <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ring-2 ring-[#0c101d] ${currentPresence.color}`} />
            </div>
            <div className="text-left hidden md:block pr-1">
              <span className="text-xs font-semibold text-slate-200 block leading-tight">{currentUser.name}</span>
              <span className="text-[10px] text-slate-400 capitalize block leading-none">{currentUser.presenceState}</span>
            </div>
          </button>

          {showPresenceMenu && (
            <div className="absolute right-0 top-12 w-56 bg-[#111728] border border-slate-700 rounded-xl shadow-2xl p-2 z-50 text-xs space-y-1">
              <div className="px-2 py-1.5 border-b border-slate-800 mb-1">
                <p className="font-semibold text-slate-200">{currentUser.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{currentUser.email}</p>
              </div>

              <span className="px-2 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Set Presence State
              </span>

              {PRESENCE_OPTIONS.map((opt) => (
                <button
                  key={opt.status}
                  onClick={() => {
                    onUpdatePresence(opt.status);
                    setShowPresenceMenu(false);
                  }}
                  className={`w-full px-2 py-1.5 rounded-lg text-left flex items-center gap-2 cursor-pointer ${
                    currentUser.presenceState === opt.status ? 'bg-purple-600/30 text-white font-medium' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Circle className={`w-2.5 h-2.5 fill-current ${opt.color.replace('bg-', 'text-')}`} />
                  <span className="capitalize">{opt.label}</span>
                </button>
              ))}

              <div className="border-t border-slate-800 pt-1 mt-1">
                <button
                  onClick={() => {
                    setShowPresenceMenu(false);
                    onOpenSettings();
                  }}
                  className="w-full px-2 py-1.5 rounded-lg text-left text-slate-300 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <SettingsIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>Account Settings</span>
                </button>
                <button
                  onClick={() => {
                    setShowPresenceMenu(false);
                    onLogout();
                  }}
                  className="w-full px-2 py-1.5 rounded-lg text-left text-rose-400 hover:bg-rose-950/40 flex items-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Settings Icon */}
        <button
          type="button"
          onClick={onOpenSettings}
          className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/60 text-slate-300 text-xs flex items-center cursor-pointer transition-colors"
          title="Settings"
        >
          <SettingsIcon className="w-4 h-4 text-slate-300" />
        </button>
      </div>
    </header>
  );
};
