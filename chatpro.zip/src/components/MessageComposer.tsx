import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Smile,
  Mic,
  Square,
  Image as ImageIcon,
  Video,
  MapPin,
  BarChart2,
  Clock,
  X,
  Sparkles
} from 'lucide-react';
import { isSinhalaText } from '../services/sinhala';
import { VoiceRecorder } from '../services/voice';
import { ChatMessage, PollData, LocationData } from '../types';

interface MessageComposerProps {
  onSendMessage: (text: string, mediaType?: 'text' | 'photo' | 'video' | 'voice' | 'location' | 'poll' | 'sticker', mediaUrl?: string, metadata?: Record<string, unknown>, duration?: number) => void;
  replyingTo: ChatMessage | null;
  onCancelReply: () => void;
  onOpenPollModal: () => void;
  onOpenScheduleModal: () => void;
}

const STICKERS = [
  '😀', '😂', '😍', '🥰', '😎', '🤩',
  '😇', '🥳', '🤗', '😜', '🤔', '😴',
  '😭', '😡', '❤️', '💖', '🔥', '👍',
  '👏', '🎉', '🚀', '✨', '💯', '🙏', '🌟'
];

export const MessageComposer: React.FC<MessageComposerProps> = ({
  onSendMessage,
  replyingTo,
  onCancelReply,
  onOpenPollModal,
  onOpenScheduleModal
}) => {
  const [inputText, setInputText] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  const voiceRecorderRef = useRef<VoiceRecorder | null>(null);
  const recordIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);

  const isSinhala = isSinhalaText(inputText);

  // Voice recording timer
  useEffect(() => {
    if (isRecording) {
      recordIntervalRef.current = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
      setRecordSeconds(0);
    }
    return () => {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    };
  }, [isRecording]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    onSendMessage(inputText.trim(), 'text');
    setInputText('');
    setShowStickerPicker(false);
    setShowAttachMenu(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Voice Recording Handlers
  const startRecording = async () => {
    voiceRecorderRef.current = new VoiceRecorder();
    const ok = await voiceRecorderRef.current.start();
    if (ok) {
      setIsRecording(true);
    } else {
      alert('Could not access microphone. Please check browser permissions.');
    }
  };

  const stopAndSendRecording = async () => {
    if (!voiceRecorderRef.current) return;
    const res = await voiceRecorderRef.current.stop();
    setIsRecording(false);
    if (res && res.audioUrl) {
      onSendMessage('', 'voice', res.audioUrl, undefined, res.duration);
    }
  };

  const cancelRecording = () => {
    if (voiceRecorderRef.current) {
      voiceRecorderRef.current.cancel();
    }
    setIsRecording(false);
  };

  // Photo / Video File Selection
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onSendMessage(file.name, 'photo', url);
    }
    setShowAttachMenu(false);
  };

  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onSendMessage(file.name, 'video', url);
    }
    setShowAttachMenu(false);
  };

  // Location Sharing (Browser Geolocation)
  const handleShareLocation = () => {
    setShowAttachMenu(false);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc: LocationData = {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            mapUrl: `https://www.google.com/maps?q=${pos.coords.latitude},${pos.coords.longitude}`
          };
          onSendMessage('📍 Shared live location', 'location', undefined, { location: loc });
        },
        () => {
          // Fallback location for demo (e.g. Colombo, Sri Lanka)
          const loc: LocationData = {
            latitude: 6.9271,
            longitude: 79.8612,
            accuracy: 10,
            mapUrl: 'https://www.google.com/maps?q=6.9271,79.8612'
          };
          onSendMessage('📍 Shared location (Colombo, Sri Lanka)', 'location', undefined, { location: loc });
        }
      );
    } else {
      const loc: LocationData = {
        latitude: 6.9271,
        longitude: 79.8612,
        mapUrl: 'https://www.google.com/maps?q=6.9271,79.8612'
      };
      onSendMessage('📍 Shared location', 'location', undefined, { location: loc });
    }
  };

  const handleSendSticker = (emoji: string) => {
    onSendMessage(emoji, 'sticker');
    setShowStickerPicker(false);
  };

  return (
    <div className="p-3 sm:p-4 bg-[#0d1220]/95 border-t border-slate-800/80 backdrop-blur-md relative z-20 shrink-0">
      {/* Replying Banner */}
      {replyingTo && (
        <div className="mb-2 p-2 px-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs">
          <div className="truncate pr-2">
            <span className="font-semibold text-purple-300">Replying to {replyingTo.senderName}: </span>
            <span className="text-slate-300 truncate">{replyingTo.text || '[Media content]'}</span>
          </div>
          <button
            type="button"
            onClick={onCancelReply}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Hidden inputs for media */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        onChange={handlePhotoSelect}
        className="hidden"
      />
      <input
        type="file"
        ref={videoInputRef}
        accept="video/*"
        onChange={handleVideoSelect}
        className="hidden"
      />

      {/* Attach Menu Popup */}
      {showAttachMenu && (
        <div className="absolute bottom-16 left-4 bg-[#121829] border border-slate-700/80 rounded-2xl shadow-2xl p-2 z-50 text-xs w-48 space-y-1 animate-in fade-in zoom-in-95 duration-150">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full px-2.5 py-2 rounded-xl text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
          >
            <ImageIcon className="w-4 h-4 text-purple-400" />
            <span>Send Photo</span>
          </button>

          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="w-full px-2.5 py-2 rounded-xl text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
          >
            <Video className="w-4 h-4 text-teal-400" />
            <span>Send Video</span>
          </button>

          <button
            type="button"
            onClick={handleShareLocation}
            className="w-full px-2.5 py-2 rounded-xl text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-rose-400" />
            <span>Share Location</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setShowAttachMenu(false);
              onOpenPollModal();
            }}
            className="w-full px-2.5 py-2 rounded-xl text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
          >
            <BarChart2 className="w-4 h-4 text-amber-400" />
            <span>Create Poll</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setShowAttachMenu(false);
              onOpenScheduleModal();
            }}
            className="w-full px-2.5 py-2 rounded-xl text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>Schedule Message</span>
          </button>
        </div>
      )}

      {/* Sticker Picker Popup */}
      {showStickerPicker && (
        <div className="absolute bottom-16 left-12 bg-[#121829] border border-slate-700/80 rounded-2xl shadow-2xl p-3 z-50 text-xs w-64 max-h-56 overflow-y-auto animate-in fade-in zoom-in-95 duration-150 custom-scrollbar">
          <p className="text-[10px] font-semibold text-slate-400 uppercase mb-2">ChatPro Stickers</p>
          <div className="grid grid-cols-5 gap-2 text-2xl">
            {STICKERS.map((emoji, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendSticker(emoji)}
                className="hover:scale-125 transition-transform p-1 cursor-pointer flex items-center justify-center rounded-lg hover:bg-slate-800"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Composer Bar */}
      {isRecording ? (
        <div className="flex items-center gap-3 py-1 bg-red-950/30 border border-red-800/40 rounded-2xl px-4 animate-pulse">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
          <span className="text-xs font-mono font-bold text-red-400">
            Recording Voice Note: 0:{String(recordSeconds).padStart(2, '0')}
          </span>
          <div className="flex-1" />
          <button
            type="button"
            onClick={cancelRecording}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={stopAndSendRecording}
            className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-xs font-semibold text-white shadow-md cursor-pointer flex items-center gap-1"
          >
            <Square className="w-3 h-3 fill-current" />
            <span>Send Audio</span>
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          {/* Attachment Button */}
          <button
            type="button"
            onClick={() => {
              setShowAttachMenu(!showAttachMenu);
              setShowStickerPicker(false);
            }}
            className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer shrink-0"
            title="Attach media or poll"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Sticker Button */}
          <button
            type="button"
            onClick={() => {
              setShowStickerPicker(!showStickerPicker);
              setShowAttachMenu(false);
            }}
            className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer shrink-0"
            title="Stickers & Emojis"
          >
            <Smile className="w-4 h-4" />
          </button>

          {/* Text Input Field */}
          <div className="flex-1 relative flex items-center">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message (English or සිංහල)..."
              className={`w-full pl-3 pr-12 py-2.5 bg-[#090d18] border border-slate-700/80 rounded-xl text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors ${
                isSinhala ? 'font-[\'Noto_Sans_Sinhala\']' : 'font-sans'
              }`}
            />

            {/* Language indicator badge inside input */}
            <span
              className={`absolute right-3 px-1.5 py-0.5 rounded text-[9px] font-bold select-none ${
                isSinhala ? 'bg-amber-400 text-black' : 'bg-purple-900/60 text-purple-300'
              }`}
            >
              {isSinhala ? 'සිං' : 'EN'}
            </span>
          </div>

          {/* Voice Record / Send Button */}
          {inputText.trim() ? (
            <button
              type="button"
              onClick={handleSend}
              className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-600/25 transition-all active:scale-95 cursor-pointer shrink-0"
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={startRecording}
              className="p-2.5 rounded-xl bg-purple-950/50 hover:bg-purple-900/60 border border-purple-800/40 text-purple-300 hover:text-white transition-all cursor-pointer shrink-0"
              title="Hold or click to record voice message"
            >
              <Mic className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
