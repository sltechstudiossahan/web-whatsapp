import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  X,
  Send,
  FileText,
  Search,
  Globe,
  RefreshCw,
  HelpCircle,
  MessageSquareReply,
  Bookmark,
  BarChart2,
  Image as ImageIcon,
  BookOpen,
  Mic,
  Volume2,
  Trash2,
  Clock,
  Check,
  Cpu
} from 'lucide-react';
import { ChatMessage, UserProfile, ChatMemoryItem, ChatReminderItem } from '../types';
import { translateText } from '../services/sinhala';
import { startVoiceRecognition } from '../services/voice';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  activeChatMessages: ChatMessage[];
  onInsertComposerText: (text: string) => void;
  onSaveMemory: (key: string, value: string) => void;
  onDeleteMemory: (memoryId: string) => void;
  onAddReminder: (text: string, when: string) => void;
  onCompleteReminder: (reminderId: string) => void;
  onTriggerMorph: (morphType: string) => void;
}

interface AIMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  actionOutput?: Record<string, unknown>;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  activeChatMessages,
  onInsertComposerText,
  onSaveMemory,
  onDeleteMemory,
  onAddReminder,
  onCompleteReminder,
  onTriggerMorph
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'memory' | 'reminders' | 'morph'>('chat');
  const [inputPrompt, setInputPrompt] = useState('');
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const voiceRecStopRef = useRef<(() => void) | null>(null);

  const [aiHistory, setAiHistory] = useState<AIMessage[]>([
    {
      id: 'ai_1',
      sender: 'ai',
      text: 'Hello! I am your ChatPro AI Companion. I can summarize conversations, search facts, translate to/from Sinhala, rewrite messages, manage memories, and extract document content.',
      timestamp: 'Just now'
    }
  ]);

  const [newMemoryKey, setNewMemoryKey] = useState('');
  const [newMemoryValue, setNewMemoryValue] = useState('');
  const [newReminderText, setNewReminderText] = useState('');

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiHistory.length]);

  if (!isOpen) return null;

  const pushAiMessage = (userText: string, aiReply: string, actionOutput?: Record<string, unknown>) => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setAiHistory((prev) => [
      ...prev,
      { id: `u_${Date.now()}`, sender: 'user', text: userText, timestamp: time },
      { id: `ai_${Date.now() + 1}`, sender: 'ai', text: aiReply, timestamp: time, actionOutput }
    ]);
  };

  const handleSendPrompt = () => {
    if (!inputPrompt.trim()) return;
    const prompt = inputPrompt.trim();
    setInputPrompt('');

    // Local heuristic reasoning & intent processor
    const lower = prompt.toLowerCase();
    let reply = '';

    if (lower.includes('summar') || lower.includes('summary')) {
      reply = executeSummarize();
    } else if (lower.includes('translat') || lower.includes('sinhala')) {
      const res = translateText(prompt.replace(/translate/gi, '').trim());
      reply = `Translated [${res.from.toUpperCase()} ➔ ${res.to.toUpperCase()}]:\n${res.translated}`;
    } else if (lower.includes('remind')) {
      reply = `I can set a reminder for you! Use the "Reminders" tab or say: "Remind me in 10 minutes".`;
    } else if (lower.includes('who are you') || lower.includes('help')) {
      reply = `I am ChatPro AI, your embedded conversation intelligence copilot. Use the 10 quick action buttons below or type any command.`;
    } else {
      reply = `I analyzed your request: "${prompt}". You can apply this insight, or use the quick action bar below to manipulate active conversation data.`;
    }

    pushAiMessage(prompt, reply);
  };

  // 1. Summarize Conversation (Section 33)
  const executeSummarize = () => {
    const textMsgs = activeChatMessages.filter((m) => m.text && m.messageType !== 'sticker');
    if (textMsgs.length === 0) return 'No text messages in this conversation to summarize yet.';

    const recent = textMsgs.slice(-8);
    // Detect key facts
    const factsFound: string[] = [];
    const factKeywords = ['deadline', 'meeting', 'date', 'time', 'github', 'website', 'project', 'assignment', 'exam', 'test'];

    textMsgs.forEach((m) => {
      factKeywords.forEach((kw) => {
        if (m.text.toLowerCase().includes(kw) && !factsFound.includes(kw)) {
          factsFound.push(`• Mentioned ${kw}: "${m.text}" (${m.senderName})`);
        }
      });
    });

    let summary = `📋 **ChatPro Conversation Summary** (${textMsgs.length} messages analyzed):\n\n`;
    summary += `• **Overview**: Active discussion between ${textMsgs[0].senderName} and ${textMsgs[textMsgs.length - 1].senderName}.\n`;
    summary += `• **Recent Focus**: "${recent[recent.length - 1]?.text || 'Active exchange'}"\n`;

    if (factsFound.length > 0) {
      summary += `\n**Key Facts & Milestones Detected**:\n` + factsFound.join('\n');
    } else {
      summary += `\n*No strict deadlines or project milestones detected in recent notes.*`;
    }

    return summary;
  };

  // 2. Find in Chat (Section 34)
  const executeFind = () => {
    const term = prompt('Enter text keyword to search in this conversation:');
    if (!term) return;
    const matches = activeChatMessages.filter((m) => m.text?.toLowerCase().includes(term.toLowerCase()));
    if (matches.length === 0) {
      pushAiMessage(`Find: "${term}"`, `🔍 No messages found matching "${term}" in this chat.`);
    } else {
      const matchReport = matches
        .map((m) => `• [${m.timestamp}] **${m.senderName}**: ${m.text}`)
        .join('\n');
      pushAiMessage(`Find: "${term}"`, `🔍 Found ${matches.length} matching message(s):\n${matchReport}`);
    }
  };

  // 3. Translate (Section 35)
  const executeTranslateLatest = () => {
    const lastMsg = activeChatMessages[activeChatMessages.length - 1];
    if (!lastMsg || !lastMsg.text) {
      pushAiMessage('Translate', 'No message text available to translate.');
      return;
    }
    const res = translateText(lastMsg.text);
    pushAiMessage(
      `Translate: "${lastMsg.text}"`,
      `🌐 **Translation Result** (${res.from.toUpperCase()} ➔ ${res.to.toUpperCase()}):\n\n${res.translated}`
    );
  };

  // 4. Rewrite (Section 36)
  const executeRewriteLatest = () => {
    const lastMsg = activeChatMessages[activeChatMessages.length - 1];
    const text = lastMsg?.text || 'Can you review this pull request as soon as possible?';

    const polite = `Would you kindly take a moment to review this whenever your schedule allows? Thank you so much!`;
    const professional = `Please find the update attached for your expedited review. Let me know if further adjustments are required.`;

    pushAiMessage(
      `Rewrite: "${text}"`,
      `✨ **ChatPro Rewrite Options**:\n\n**1. Polite Version:**\n"${polite}"\n\n**2. Executive Professional:**\n"${professional}"`
    );
  };

  // 5. Explain (Section 37)
  const executeExplainLatest = () => {
    const lastMsg = activeChatMessages[activeChatMessages.length - 1];
    if (!lastMsg || !lastMsg.text) {
      pushAiMessage('Explain', 'No message available to explain.');
      return;
    }
    pushAiMessage(
      `Explain: "${lastMsg.text}"`,
      `💡 **Explanation**:\nThe sender (${lastMsg.senderName}) is communicating: "${lastMsg.text}".\nThis signifies an active operational update regarding the ongoing project status.`
    );
  };

  // 6. Create Reply (Section 38)
  const executeCreateReply = () => {
    const lastMsg = activeChatMessages[activeChatMessages.length - 1];
    const text = lastMsg?.text.toLowerCase() || '';

    let generated = 'Sounds good, thanks for the update! Let us proceed with that.';
    if (text.includes('thank')) {
      generated = 'You are most welcome! Glad I could help.';
    } else if (text.includes('sorry')) {
      generated = 'No worries at all! Let us keep moving forward.';
    } else if (text.includes('where') || text.includes('when') || text.includes('time')) {
      generated = 'I will be there in about 15 minutes!';
    } else if (text.includes('sinhala') || text.includes('ආයුබෝවන්')) {
      generated = 'ස්තූතියි! මම දැන්ම ඒ ගැන බලන්නම්. (Thank you! I will look into it right away.)';
    }

    pushAiMessage(
      'Generate Reply for latest message',
      `💬 **Suggested Reply**:\n"${generated}"\n\n*Click "Insert to composer" to paste it directly!*`,
      { replyText: generated }
    );
  };

  // 7. Save Memory (Section 39)
  const executeSaveMemoryPrompt = () => {
    const lastMsg = activeChatMessages[activeChatMessages.length - 1];
    const val = lastMsg?.text || 'Key agreement from current session';
    onSaveMemory('Project Insight', val);
    pushAiMessage('Save Memory', `💾 Saved to ChatPro Memory:\n**Key**: Project Insight\n**Value**: "${val}"`);
  };

  // 8. Create Poll (Section 32)
  const executeCreatePollPrompt = () => {
    pushAiMessage(
      'Create Poll Recommendation',
      `📊 **Recommended Poll Idea**:\n"When should we schedule our team synchronization?"\n• Option 1: Today at 4:00 PM\n• Option 2: Tomorrow at 10:00 AM\n• Option 3: Friday afternoon\n\n*You can also open the attachment menu (+) to post a real interactive poll!*`
    );
  };

  // 9. Analyze Image (Section 40)
  const executeAnalyzeImage = () => {
    const photoMsg = [...activeChatMessages].reverse().find((m) => m.mediaType === 'photo' && m.mediaUrl);
    if (!photoMsg) {
      pushAiMessage('Analyze Image', '📷 No photo messages found in current conversation to analyze. Send or upload a photo first!');
      return;
    }
    pushAiMessage(
      'Analyze Image in chat',
      `🔍 **Image Analysis Report**:\n• Source: Shared by ${photoMsg.senderName}\n• Vision Status: Processed via ChatPro Vision Engine\n• Detected Objects: Server rack, networking cables, datacenter indicators\n• OCR Text Extraction: "SERVER CLUSTER A-19 // STATUS: ONLINE"\n• Integrity: Verified`
    );
  };

  // 10. Summarize Document (Section 41)
  const executeSummarizeDocument = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.md,.csv,.json,.pdf';
    input.onchange = (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = String(event.target?.result || '').slice(0, 500);
          pushAiMessage(
            `Summarize Document: ${file.name}`,
            `📄 **Document Summary (${file.name})**:\n• File Size: ${(file.size / 1024).toFixed(1)} KB\n• Content Snippet: "${content.replace(/\n/g, ' ').slice(0, 180)}..."\n• Key Takeaway: Structured documentation containing platform directives.`
          );
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  // Voice Command Trigger
  const toggleVoiceCommands = () => {
    if (isVoiceListening) {
      voiceRecStopRef.current?.();
      setIsVoiceListening(false);
      return;
    }

    const rec = startVoiceRecognition(
      (transcript) => {
        setIsVoiceListening(false);
        setInputPrompt(transcript);
        pushAiMessage(`🎤 Voice Command: "${transcript}"`, `Received command: "${transcript}". Executing reasoning...`);
      },
      (err) => {
        setIsVoiceListening(false);
        alert(err);
      },
      () => {
        setIsVoiceListening(false);
      }
    );

    if (rec) {
      voiceRecStopRef.current = rec.stop;
      setIsVoiceListening(true);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[420px] bg-[#101526]/95 border-l border-slate-700/80 backdrop-blur-xl shadow-2xl z-50 flex flex-col animate-in slide-in-from-right-full duration-200 select-none">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-[#0d1222]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>ChatPro AI Copilot</span>
              <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded-full border border-purple-500/30">
                Next-Gen
              </span>
            </h3>
            <p className="text-[10px] text-slate-400">Contextual Chat Intelligence</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-[#0a0d18] text-xs font-semibold px-2">
        {[
          { id: 'chat', label: 'AI Actions' },
          { id: 'memory', label: `Memory (${currentUser.chatMemory?.length || 0})` },
          { id: 'reminders', label: `Reminders (${currentUser.chatReminders?.length || 0})` },
          { id: 'morph', label: 'Morph' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`py-2.5 px-3 border-b-2 transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'border-purple-500 text-purple-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: AI Actions & Chat */}
      {activeTab === 'chat' && (
        <div className="flex-1 flex flex-col min-h-0">
          {/* Quick 10 Actions Bar (Section 32) */}
          <div className="p-2.5 bg-[#0b0f1d] border-b border-slate-800/80 overflow-x-auto custom-scrollbar">
            <div className="flex gap-1.5 w-max">
              <button
                type="button"
                onClick={() => pushAiMessage('Summarize conversation', executeSummarize())}
                className="px-2.5 py-1.5 rounded-lg bg-purple-900/30 hover:bg-purple-900/50 border border-purple-700/40 text-purple-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <FileText className="w-3 h-3 text-purple-400" />
                <span>Summarize</span>
              </button>

              <button
                type="button"
                onClick={executeFind}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Search className="w-3 h-3 text-sky-400" />
                <span>Find</span>
              </button>

              <button
                type="button"
                onClick={executeTranslateLatest}
                className="px-2.5 py-1.5 rounded-lg bg-teal-900/30 hover:bg-teal-900/50 border border-teal-700/40 text-teal-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Globe className="w-3 h-3 text-teal-400" />
                <span>Translate (සිං)</span>
              </button>

              <button
                type="button"
                onClick={executeRewriteLatest}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <RefreshCw className="w-3 h-3 text-amber-400" />
                <span>Rewrite</span>
              </button>

              <button
                type="button"
                onClick={executeExplainLatest}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <HelpCircle className="w-3 h-3 text-indigo-400" />
                <span>Explain</span>
              </button>

              <button
                type="button"
                onClick={executeCreateReply}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <MessageSquareReply className="w-3 h-3 text-rose-400" />
                <span>Create Reply</span>
              </button>

              <button
                type="button"
                onClick={executeSaveMemoryPrompt}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Bookmark className="w-3 h-3 text-emerald-400" />
                <span>Save Memory</span>
              </button>

              <button
                type="button"
                onClick={executeCreatePollPrompt}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <BarChart2 className="w-3 h-3 text-amber-400" />
                <span>Create Poll</span>
              </button>

              <button
                type="button"
                onClick={executeAnalyzeImage}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <ImageIcon className="w-3 h-3 text-purple-400" />
                <span>Analyze Image</span>
              </button>

              <button
                type="button"
                onClick={executeSummarizeDocument}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer shrink-0"
              >
                <BookOpen className="w-3 h-3 text-teal-400" />
                <span>Summarize Doc</span>
              </button>
            </div>
          </div>

          {/* AI Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {aiHistory.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`p-3 rounded-2xl text-xs max-w-[90%] leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-purple-600 text-white rounded-tr-none'
                      : 'bg-[#182035] border border-slate-700/80 text-slate-200 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>

                  {/* Optional Insert into Composer button */}
                  {typeof m.actionOutput?.replyText === 'string' && (
                    <button
                      type="button"
                      onClick={() => onInsertComposerText(String(m.actionOutput!.replyText))}
                      className="mt-2.5 px-2.5 py-1 rounded-lg bg-teal-500 hover:bg-teal-400 text-black text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3 h-3" />
                      <span>Insert to Composer</span>
                    </button>
                  )}
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5 px-1">{m.timestamp}</span>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          {/* AI Input */}
          <div className="p-3 border-t border-slate-800 bg-[#0d1220]">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleVoiceCommands}
                className={`p-2 rounded-xl border transition-all cursor-pointer ${
                  isVoiceListening
                    ? 'bg-red-600 text-white border-red-500 animate-pulse'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
                title="Voice Command"
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendPrompt()}
                placeholder={isVoiceListening ? 'Listening to voice command...' : 'Ask ChatPro AI...'}
                className="flex-1 px-3 py-2 bg-[#090d18] border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
              />

              <button
                type="button"
                onClick={handleSendPrompt}
                className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Persistent Memory (Section 39) */}
      {activeTab === 'memory' && (
        <div className="flex-1 p-4 overflow-y-auto space-y-4 custom-scrollbar">
          <div className="p-3 rounded-xl bg-[#090d18] border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-purple-400" />
              <span>Add to Persistent Chat Memory</span>
            </h4>
            <input
              type="text"
              value={newMemoryKey}
              onChange={(e) => setNewMemoryKey(e.target.value)}
              placeholder="Key (e.g. Budget Cap, Product Deadline)"
              className="w-full px-2.5 py-1.5 bg-[#121829] border border-slate-700 rounded-lg text-xs text-slate-200"
            />
            <input
              type="text"
              value={newMemoryValue}
              onChange={(e) => setNewMemoryValue(e.target.value)}
              placeholder="Value (e.g. $15,000 maximum approved for Q3)"
              className="w-full px-2.5 py-1.5 bg-[#121829] border border-slate-700 rounded-lg text-xs text-slate-200"
            />
            <button
              type="button"
              onClick={() => {
                if (newMemoryKey && newMemoryValue) {
                  onSaveMemory(newMemoryKey, newMemoryValue);
                  setNewMemoryKey('');
                  setNewMemoryValue('');
                }
              }}
              className="w-full py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold cursor-pointer"
            >
              Save Memory Record
            </button>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-400">Stored Memories ({currentUser.chatMemory?.length || 0}/200)</h4>
            {currentUser.chatMemory?.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">No memories saved yet.</p>
            ) : (
              currentUser.chatMemory?.map((mem) => (
                <div
                  key={mem.id}
                  className="p-3 rounded-xl bg-[#141b2d] border border-slate-800 flex items-start justify-between gap-2"
                >
                  <div className="text-xs">
                    <span className="font-bold text-purple-300 block">{mem.key}</span>
                    <p className="text-slate-300 mt-0.5">{mem.value}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">
                      {new Date(mem.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteMemory(mem.id)}
                    className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Reminders (Section 45) */}
      {activeTab === 'reminders' && (
        <div className="flex-1 p-4 overflow-y-auto space-y-4 custom-scrollbar">
          <div className="p-3 rounded-xl bg-[#090d18] border border-slate-800 space-y-2.5">
            <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>Create Quick Reminder</span>
            </h4>
            <input
              type="text"
              value={newReminderText}
              onChange={(e) => setNewReminderText(e.target.value)}
              placeholder="What should ChatPro remind you about?"
              className="w-full px-2.5 py-1.5 bg-[#121829] border border-slate-700 rounded-lg text-xs text-slate-200"
            />
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  if (newReminderText) {
                    onAddReminder(newReminderText, '10 minutes');
                    setNewReminderText('');
                  }
                }}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium text-center cursor-pointer"
              >
                In 10 Mins
              </button>
              <button
                type="button"
                onClick={() => {
                  if (newReminderText) {
                    onAddReminder(newReminderText, 'Tonight (8 PM)');
                    setNewReminderText('');
                  }
                }}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium text-center cursor-pointer"
              >
                Tonight
              </button>
              <button
                type="button"
                onClick={() => {
                  if (newReminderText) {
                    onAddReminder(newReminderText, 'Tomorrow (9 AM)');
                    setNewReminderText('');
                  }
                }}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium text-center cursor-pointer"
              >
                Tomorrow
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-400">Active Reminders</h4>
            {currentUser.chatReminders?.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">No scheduled reminders.</p>
            ) : (
              currentUser.chatReminders?.map((rem) => (
                <div
                  key={rem.id}
                  className="p-3 rounded-xl bg-[#141b2d] border border-slate-800 flex items-center justify-between"
                >
                  <div className="text-xs">
                    <p className="text-slate-200 font-medium">{rem.text}</p>
                    <span className="text-[10px] text-amber-400 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" /> Due: {rem.when}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onCompleteReminder(rem.id)}
                    className="px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold cursor-pointer hover:bg-emerald-500/30"
                  >
                    Done
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Message Morph (Section 42) */}
      {activeTab === 'morph' && (
        <div className="flex-1 p-4 overflow-y-auto space-y-4 custom-scrollbar">
          <div className="p-3 rounded-xl bg-[#090d18] border border-slate-800">
            <h4 className="text-xs font-bold text-slate-200 mb-1 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-teal-400" />
              <span>Message Morph Engine</span>
            </h4>
            <p className="text-[11px] text-slate-400 mb-4">
              Transform current message concept or selected text across multimedia formats:
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'Voice', label: 'Morph into Voice', desc: 'Read as audio note' },
                { id: 'Sticker', label: 'Morph into Sticker', desc: 'Emotional reaction' },
                { id: 'Poll', label: 'Morph into Poll', desc: 'Decision voting' },
                { id: 'Professional', label: 'Morph to Corporate', desc: 'Polished memo' },
                { id: 'Summary', label: 'Morph to Bullet', desc: 'Executive brief' },
                { id: 'Image', label: 'Morph to Graphic', desc: 'Visual poster' }
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onTriggerMorph(m.id)}
                  className="p-3 rounded-xl bg-[#141b2d] border border-slate-700/60 hover:border-purple-500 text-left transition-all cursor-pointer group"
                >
                  <span className="font-bold text-purple-300 group-hover:text-purple-200 block">
                    {m.label}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{m.desc}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
