import React, { useState } from 'react';
import {
  Search,
  Lock,
  Unlock,
  UserPlus,
  Pin,
  UserCheck,
  AlertTriangle,
  X,
  ShieldAlert
} from 'lucide-react';
import { UserProfile, UserContact, ChatMessage } from '../types';

interface ContactSidebarProps {
  currentUser: UserProfile;
  contacts: UserContact[];
  unknownChats: { email: string; name: string; lastMessage: string; timestamp: string }[];
  activeChatEmail: string | null;
  onSelectContact: (contact: UserContact) => void;
  onAddContact: (name: string, email: string) => void;
  onUnlockContactList: (password: string) => Promise<boolean>;
  onLockContactList: () => void;
  allMessages: ChatMessage[];
  pinnedMessageIds: string[];
}

export const ContactSidebar: React.FC<ContactSidebarProps> = ({
  currentUser,
  contacts,
  unknownChats,
  activeChatEmail,
  onSelectContact,
  onAddContact,
  onUnlockContactList,
  onLockContactList
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockError, setUnlockError] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactEmail, setNewContactEmail] = useState('');
  const [addError, setAddError] = useState('');

  const isListLocked = currentUser.contactListLocked;

  const handleUnlockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUnlockError(false);
    const success = await onUnlockContactList(unlockPassword);
    if (!success) {
      setUnlockError(true);
    } else {
      setUnlockPassword('');
    }
  };

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    setAddError('');
    if (!newContactEmail.trim() || !newContactEmail.includes('@')) {
      setAddError('Please enter a valid email address');
      return;
    }
    if (!newContactName.trim()) {
      setAddError('Please enter a contact name');
      return;
    }

    onAddContact(newContactName.trim(), newContactEmail.trim().toLowerCase());
    setNewContactName('');
    setNewContactEmail('');
    setShowAddModal(false);
  };

  const filteredContacts = contacts.filter((c) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q);
  });

  return (
    <aside className="w-full md:w-80 lg:w-96 h-full flex flex-col bg-[#0e1322] border-r border-slate-800/80 shrink-0 select-none">
      {/* Search & Add Header */}
      <div className="p-3.5 border-b border-slate-800/80 space-y-2.5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-200 tracking-tight flex items-center gap-2">
            <span>Conversations</span>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
              {contacts.length}
            </span>
          </h2>
          <div className="flex items-center gap-1">
            {currentUser.lockPasswordHash && (
              <button
                type="button"
                onClick={() => {
                  if (isListLocked) {
                    // focus search
                  } else {
                    onLockContactList();
                  }
                }}
                className={`p-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
                  isListLocked
                    ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
                title={isListLocked ? 'Contact list is locked' : 'Lock contact list'}
              >
                {isListLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="p-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs flex items-center gap-1 cursor-pointer transition-colors"
              title="Add New Contact"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span className="text-[11px] font-medium hidden sm:inline">Add</span>
            </button>
          </div>
        </div>

        {/* Search Bar / Privacy Password Field */}
        {isListLocked ? (
          <form onSubmit={handleUnlockSubmit} className="relative">
            <Lock className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="password"
              value={unlockPassword}
              onChange={(e) => {
                setUnlockPassword(e.target.value);
                setUnlockError(false);
              }}
              placeholder="Enter Privacy Password to unlock contacts..."
              className="w-full pl-9 pr-16 py-2 bg-[#090d18] border border-amber-500/40 rounded-xl text-xs text-amber-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
            <button
              type="submit"
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-2 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-bold cursor-pointer"
            >
              Unlock
            </button>
          </form>
        ) : (
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contacts or email..."
              className="w-full pl-9 pr-3 py-2 bg-[#090d18] border border-slate-700/60 rounded-xl text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
            />
          </div>
        )}

        {unlockError && (
          <p className="text-[11px] text-red-400 flex items-center gap-1">
            <ShieldAlert className="w-3 h-3" /> Incorrect privacy password.
          </p>
        )}
      </div>

      {/* Unknown Incoming Chats Banner (Section 10) */}
      {!isListLocked && unknownChats.length > 0 && (
        <div className="px-3 py-2 bg-amber-500/10 border-b border-amber-500/20">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold text-amber-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Incoming Unknown Messages ({unknownChats.length})
            </span>
          </div>
          <div className="space-y-1">
            {unknownChats.map((unk) => (
              <div
                key={unk.email}
                className="p-2 rounded-lg bg-[#0b101e] border border-amber-500/30 flex items-center justify-between"
              >
                <div
                  className="cursor-pointer flex-1 min-w-0 mr-2"
                  onClick={() =>
                    onSelectContact({
                      email: unk.email,
                      name: unk.name,
                      emoji: '❓',
                      about: 'Unknown user from ChatPro network'
                    })
                  }
                >
                  <p className="text-xs font-semibold text-slate-200 truncate">{unk.name}</p>
                  <p className="text-[10px] text-slate-400 truncate">{unk.lastMessage}</p>
                </div>
                <button
                  type="button"
                  onClick={() => onAddContact(unk.name, unk.email)}
                  className="p-1 px-2 rounded-md bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-bold flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <UserPlus className="w-3 h-3" />
                  <span>Save</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Contact List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40 custom-scrollbar">
        {isListLocked ? (
          <div className="h-full flex flex-col items-center justify-center p-6 text-center text-slate-500">
            <Lock className="w-10 h-10 text-amber-400/60 mb-2" />
            <p className="text-xs font-semibold text-slate-300">Contact List Locked</p>
            <p className="text-[11px] text-slate-400 mt-1 max-w-[200px]">
              Enter your privacy password in the search bar above to access your encrypted conversations.
            </p>
          </div>
        ) : filteredContacts.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-6 text-center text-slate-500">
            <p className="text-xs font-medium">No contacts found</p>
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="mt-3 px-3 py-1.5 rounded-lg bg-purple-600/30 hover:bg-purple-600/40 text-purple-300 text-xs font-medium border border-purple-500/30 cursor-pointer"
            >
              Add First Contact
            </button>
          </div>
        ) : (
          filteredContacts.map((contact) => {
            const isSelected = activeChatEmail?.toLowerCase() === contact.email.toLowerCase();
            const isChatLocked = currentUser.lockedChats?.includes(contact.email.toLowerCase());

            return (
              <button
                key={contact.email}
                type="button"
                onClick={() => onSelectContact(contact)}
                className={`w-full p-3.5 flex items-center gap-3 text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-purple-900/25 border-l-4 border-l-purple-500'
                    : 'hover:bg-slate-800/40'
                }`}
              >
                {/* Avatar */}
                <div className="relative shrink-0">
                  {contact.profilePhoto ? (
                    <img
                      src={contact.profilePhoto}
                      alt={contact.name}
                      className="w-11 h-11 rounded-xl object-cover"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-xl bg-[#1a2238] border border-slate-700/60 flex items-center justify-center text-lg">
                      {contact.emoji || '👤'}
                    </div>
                  )}
                  {/* Online dot */}
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-[#0e1322]" />
                </div>

                {/* Contact Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="text-xs font-semibold text-slate-100 truncate">{contact.name}</span>
                      {contact.emoji && <span className="text-xs">{contact.emoji}</span>}
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0 ml-1">
                      {contact.lastMessageTime || '10:40 AM'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-[11px] text-slate-400 truncate pr-2">
                      {isChatLocked ? '🔒 [Locked conversation]' : contact.lastMessage || contact.about || 'Start conversation...'}
                    </p>
                    <div className="flex items-center gap-1 shrink-0">
                      {isChatLocked && <Lock className="w-3 h-3 text-amber-400" />}
                      {contact.isPinned && <Pin className="w-3 h-3 text-purple-400" />}
                    </div>
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Add Contact Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#121829] border border-slate-700 rounded-2xl p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-purple-400" />
                <span>Add New Contact</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {addError && (
              <div className="mb-3 p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                {addError}
              </div>
            )}

            <form onSubmit={handleCreateContact} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 mb-1">Contact Name</label>
                <input
                  type="text"
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder="e.g. Dilshan Silva"
                  className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  value={newContactEmail}
                  onChange={(e) => setNewContactEmail(e.target.value)}
                  placeholder="dilshan@chatapp.com"
                  className="w-full px-3 py-2 bg-[#0a0d18] border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white shadow-md shadow-purple-600/25 cursor-pointer flex items-center justify-center gap-1"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Save Contact</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </aside>
  );
};
