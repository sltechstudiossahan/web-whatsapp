import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  ChatMessage,
  UserContact,
  ActiveCall,
  IdentityDetails,
  ThemePreset,
  PresenceStatus
} from './types';
import {
  StorageService,
  deterministicChatId,
  verifyPasswordPBKDF2
} from './services/storage';
import { detectLanguage } from './services/sinhala';
import { AuthScreen } from './components/AuthScreen';
import { IdentityVerificationScreen } from './components/IdentityVerificationScreen';
import { Navbar } from './components/Navbar';
import { ContactSidebar } from './components/ContactSidebar';
import { ChatHeader } from './components/ChatHeader';
import { MessageFeed } from './components/MessageFeed';
import { MessageComposer } from './components/MessageComposer';
import { AIAssistantModal } from './components/AIAssistantModal';
import { CallModal } from './components/CallModal';
import { SettingsScreen } from './components/SettingsScreen';
import { AdminCenterModal } from './components/AdminCenterModal';
import {
  MediaLightboxModal,
  PollCreatorModal,
  ScheduleModal,
  ForwardModal,
  ContactInfoModal
} from './components/Modals';

export default function App() {
  // Profiles & Messages
  const [profiles, setProfiles] = useState<UserProfile[]>(() => StorageService.getProfiles());
  const [allMessages, setAllMessages] = useState<ChatMessage[]>(() => StorageService.getMessages());
  const [currentUserEmail, setCurrentUserEmail] = useState<string>(() => StorageService.getCurrentUserEmail());

  // Navigation State: 'auth' | 'identity' | 'messenger'
  const [currentScreen, setCurrentScreen] = useState<'auth' | 'identity' | 'messenger'>('messenger');

  // Active Chat State
  const [activeContact, setActiveContact] = useState<UserContact | null>(null);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [searchInChatQuery, setSearchInChatQuery] = useState('');
  const [showSearchInChat, setShowSearchInChat] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Mobile View State: show chat pane instead of contact list on small screens
  const [isMobileChatOpen, setIsMobileChatOpen] = useState(false);

  // Stars & Pins (localStorage)
  const [starredIds, setStarredIds] = useState<string[]>(() => StorageService.getStarredMessageIds());
  const [pinnedIds, setPinnedIds] = useState<string[]>(() => StorageService.getPinnedMessageIds());

  // Themes
  const [activeTheme, setActiveTheme] = useState<ThemePreset>(() => (StorageService.getTheme() as ThemePreset) || 'cyberpunk');

  // Modals
  const [isAIOpen, setIsAIOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPollModalOpen, setIsPollModalOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isForwardModalOpen, setIsForwardModalOpen] = useState(false);
  const [forwardMessageTarget, setForwardMessageTarget] = useState<ChatMessage | null>(null);
  const [isContactInfoModalOpen, setIsContactInfoModalOpen] = useState(false);
  const [lightboxState, setLightboxState] = useState<{ open: boolean; url: string | null; type: 'photo' | 'video' }>({
    open: false,
    url: null,
    type: 'photo'
  });

  // Call System
  const [activeCall, setActiveCall] = useState<ActiveCall>({
    active: false,
    type: 'voice',
    contact: { email: '', name: '' },
    status: 'calling',
    isMuted: false,
    isVideoOff: false
  });

  // Get active user object
  const currentUser = profiles.find((p) => p.email.toLowerCase() === currentUserEmail.toLowerCase()) || profiles[0];

  // Initialize Screen routing based on user state
  useEffect(() => {
    if (!currentUser) {
      setCurrentScreen('auth');
      return;
    }
    // Section 2: If neither admin nor nicCaptured, direct to identity capture screen
    if (!currentUser.isAdmin && !currentUser.nicCaptured) {
      setCurrentScreen('identity');
    } else {
      setCurrentScreen('messenger');
    }
  }, [currentUser?.email, currentUser?.nicCaptured, currentUser?.isAdmin]);

  // Set default active contact on initial load
  useEffect(() => {
    if (!activeContact && currentUser?.contacts?.length > 0) {
      setActiveContact(currentUser.contacts[0]);
    }
  }, [currentUser]);

  // Unknown Incoming Users Discovery (Section 10)
  // Polls message metadata every 8s to discover senders not in current user's contact list
  const [unknownChats, setUnknownChats] = useState<{ email: string; name: string; lastMessage: string; timestamp: string }[]>([]);

  useEffect(() => {
    const discoverUnknown = () => {
      const knownEmails = new Set((currentUser?.contacts || []).map((c) => c.email.toLowerCase()));
      knownEmails.add(currentUser.email.toLowerCase());

      const discovered: Record<string, { email: string; name: string; lastMessage: string; timestamp: string }> = {};

      allMessages.forEach((msg) => {
        if (msg.recipient.toLowerCase() === currentUser.email.toLowerCase()) {
          const senderEmail = msg.sender.toLowerCase();
          if (!knownEmails.has(senderEmail)) {
            discovered[senderEmail] = {
              email: msg.sender,
              name: msg.senderName,
              lastMessage: msg.text || `[${msg.messageType}]`,
              timestamp: msg.timestamp
            };
          }
        }
      });

      setUnknownChats(Object.values(discovered));
    };

    discoverUnknown();
    const interval = setInterval(discoverUnknown, 8000);
    return () => clearInterval(interval);
  }, [allMessages, currentUser]);

  // Scheduled Messages Background Releaser (Section 22)
  // Scans for scheduled messages every 10s and marks them sent if due
  useEffect(() => {
    const checkScheduled = () => {
      const now = new Date();
      let changed = false;
      const updated = allMessages.map((m) => {
        if (m.status === 'scheduled' && m.scheduledAt) {
          const schedTime = new Date(m.scheduledAt);
          if (schedTime <= now) {
            changed = true;
            return {
              ...m,
              status: 'sent' as const,
              timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
          }
        }
        return m;
      });

      if (changed) {
        setAllMessages(updated);
        StorageService.saveMessages(updated);
      }
    };

    const timer = setInterval(checkScheduled, 10000);
    return () => clearInterval(timer);
  }, [allMessages]);

  // Filter messages for currently selected chat
  const activeChatId = activeContact ? deterministicChatId(currentUser.email, activeContact.email) : '';
  const currentChatMessages = allMessages.filter((m) => m.chatId === activeChatId);

  // Send Message Handler
  const handleSendMessage = (
    text: string,
    mediaType: 'text' | 'photo' | 'video' | 'voice' | 'location' | 'poll' | 'sticker' = 'text',
    mediaUrl?: string,
    metadata?: Record<string, unknown>,
    duration?: number
  ) => {
    if (!activeContact) return;

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const lang = detectLanguage(text);

    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      chatId: activeChatId,
      sender: currentUser.email,
      senderName: currentUser.name,
      recipient: activeContact.email,
      recipientName: activeContact.name,
      timestamp: time,
      language: lang,
      text,
      mediaType: mediaType !== 'text' ? mediaType : undefined,
      mediaUrl,
      duration,
      status: 'read',
      messageType: mediaType,
      metadata: {
        ...metadata,
        replyToId: replyingTo?.id,
        replyToText: replyingTo?.text,
        replyToSender: replyingTo?.senderName
      }
    };

    const updated = [...allMessages, newMessage];
    setAllMessages(updated);
    StorageService.saveMessages(updated);
    setReplyingTo(null);

    // Update Contact's Last Message Snippet
    const updatedProfiles = profiles.map((p) => {
      if (p.email.toLowerCase() === currentUser.email.toLowerCase()) {
        const cIdx = p.contacts.findIndex((c) => c.email.toLowerCase() === activeContact.email.toLowerCase());
        if (cIdx >= 0) {
          p.contacts[cIdx].lastMessage = text || `[${mediaType}]`;
          p.contacts[cIdx].lastMessageTime = time;
        }
      }
      return p;
    });
    setProfiles(updatedProfiles);
    StorageService.saveProfiles(updatedProfiles);

    // Trigger Smart Auto-Reply if recipient has auto-reply enabled (Section 25)
    const recipientProfile = profiles.find((p) => p.email.toLowerCase() === activeContact.email.toLowerCase());
    if (recipientProfile && recipientProfile.autoReplyEnabled && recipientProfile.autoReplyText) {
      const now = Date.now();
      const lastReplyTime = recipientProfile.lastAutoReplies?.[currentUser.email] || 0;
      // 5-minute cooldown (300,000 ms)
      if (now - lastReplyTime > 300000) {
        setTimeout(() => {
          const autoMsg: ChatMessage = {
            id: `auto_${Date.now()}`,
            chatId: activeChatId,
            sender: recipientProfile.email,
            senderName: recipientProfile.name,
            recipient: currentUser.email,
            recipientName: currentUser.name,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            language: detectLanguage(recipientProfile.autoReplyText),
            text: `🤖 [Auto-Reply] ${recipientProfile.autoReplyText}`,
            status: 'delivered',
            messageType: 'text'
          };
          const withAuto = [...StorageService.getMessages(), autoMsg];
          setAllMessages(withAuto);
          StorageService.saveMessages(withAuto);

          // update cooldown map
          recipientProfile.lastAutoReplies = {
            ...(recipientProfile.lastAutoReplies || {}),
            [currentUser.email]: now
          };
          StorageService.updateProfile(recipientProfile);
        }, 1200);
      }
    }
  };

  // Poll Vote Handler (Section 20)
  const handleVotePoll = (messageId: string, optionId: string) => {
    const updated = allMessages.map((msg) => {
      if (msg.id === messageId && msg.metadata?.poll) {
        const poll = msg.metadata.poll;
        const voterEmail = currentUser.email;

        // Toggle vote on option
        let voteCountChange = 0;
        const updatedOptions = poll.options.map((opt) => {
          const hadVote = opt.votes.includes(voterEmail);
          if (opt.id === optionId) {
            if (hadVote) {
              return { ...opt, votes: opt.votes.filter((e) => e !== voterEmail) };
            } else {
              voteCountChange = 1;
              return { ...opt, votes: [...opt.votes, voterEmail] };
            }
          } else {
            // Remove previous vote from other options (single choice poll)
            if (hadVote) {
              return { ...opt, votes: opt.votes.filter((e) => e !== voterEmail) };
            }
            return opt;
          }
        });

        const allVotes = new Set<string>();
        updatedOptions.forEach((o) => o.votes.forEach((e) => allVotes.add(e)));

        return {
          ...msg,
          metadata: {
            ...msg.metadata,
            poll: {
              ...poll,
              options: updatedOptions,
              totalVotes: allVotes.size
            }
          }
        };
      }
      return msg;
    });

    setAllMessages(updated);
    StorageService.saveMessages(updated);
  };

  // Add Contact Handler
  const handleAddContact = (name: string, email: string) => {
    const existing = currentUser.contacts.find((c) => c.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      alert('This user is already in your contacts.');
      return;
    }

    const matchedProfile = profiles.find((p) => p.email.toLowerCase() === email.toLowerCase());
    const newContact: UserContact = {
      name,
      email,
      emoji: matchedProfile?.emoji || '👤',
      profilePhoto: matchedProfile?.profilePhoto,
      about: matchedProfile?.about || 'ChatPro member',
      lastMessage: 'Contact added to ChatPro.',
      lastMessageTime: 'Just now'
    };

    const updatedCurrentUser = {
      ...currentUser,
      contacts: [newContact, ...currentUser.contacts]
    };

    StorageService.updateProfile(updatedCurrentUser);
    setProfiles(StorageService.getProfiles());
    setActiveContact(newContact);
    setIsMobileChatOpen(true);
  };

  // Identity Verification Complete (Section 5)
  const handleVerificationComplete = (details: IdentityDetails, snapshotUrl: string) => {
    const updated: UserProfile = {
      ...currentUser,
      nicCaptured: true,
      nicNumber: details.documentNumber,
      nicDetails: details,
      nicPhotoUrl: snapshotUrl
    };
    StorageService.updateProfile(updated);
    setProfiles(StorageService.getProfiles());
    setCurrentScreen('messenger');
  };

  // Authentication Handlers
  const handleLogin = (email: string) => {
    StorageService.setCurrentUserEmail(email);
    setCurrentUserEmail(email);
    const profile = StorageService.getProfileByEmail(email);
    if (profile && !profile.isAdmin && !profile.nicCaptured) {
      setCurrentScreen('identity');
    } else {
      setCurrentScreen('messenger');
    }
  };

  const handleSignUp = (email: string, name: string) => {
    const newProfile: UserProfile = {
      id: `user_${Date.now()}`,
      email,
      name,
      about: 'Available on ChatPro',
      emoji: '🇱🇰',
      isAdmin: false,
      nicCaptured: false,
      profileSetup: true,
      contacts: [
        {
          email: 'admin1@chatapp.com',
          name: 'Admin Kasun',
          emoji: '🛡️',
          about: 'System Administrator & Security Lead',
          profilePhoto: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          lastMessage: 'Welcome to ChatPro! Complete your identity scan to verify your citizen profile.',
          lastMessageTime: 'Just now'
        }
      ],
      lockedChats: [],
      contactListLocked: false,
      autoReplyEnabled: false,
      autoReplyText: 'Currently busy, will reply later.',
      chatMemory: [],
      chatReminders: [],
      chatRecurring: [],
      presenceState: 'available',
      presenceVisible: true,
      lastSeen: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    StorageService.updateProfile(newProfile);
    StorageService.setCurrentUserEmail(email);
    setCurrentUserEmail(email);
    setProfiles(StorageService.getProfiles());
    setCurrentScreen('identity');
  };

  const handleLogout = () => {
    setCurrentScreen('auth');
  };

  // WebRTC Call Controls (Section 57, 58, 59)
  const startCall = (type: 'voice' | 'video') => {
    if (!activeContact) return;
    setActiveCall({
      active: true,
      type,
      contact: activeContact,
      status: 'calling',
      startTime: Date.now(),
      isMuted: false,
      isVideoOff: false
    });

    // Simulate auto-connected after 2 seconds
    setTimeout(() => {
      setActiveCall((prev) => (prev.active ? { ...prev, status: 'connected' } : prev));
    }, 2000);
  };

  const answerCall = () => {
    setActiveCall((prev) => ({ ...prev, status: 'connected' }));
  };

  const endCall = () => {
    setActiveCall({
      active: false,
      type: 'voice',
      contact: { email: '', name: '' },
      status: 'ended'
    });
  };

  // Admin Broadcast (Section 66)
  const handleAdminBroadcast = (text: string) => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newBroadcasts: ChatMessage[] = [];

    profiles.forEach((p) => {
      if (p.email.toLowerCase() !== currentUser.email.toLowerCase()) {
        newBroadcasts.push({
          id: `bcast_${Date.now()}_${p.id}`,
          chatId: deterministicChatId(currentUser.email, p.email),
          sender: currentUser.email,
          senderName: `${currentUser.name} [Official Broadcast]`,
          recipient: p.email,
          recipientName: p.name,
          timestamp: time,
          language: detectLanguage(text),
          text: `📢 ${text}`,
          isBroadcast: true,
          status: 'sent',
          messageType: 'text'
        });
      }
    });

    const updated = [...allMessages, ...newBroadcasts];
    setAllMessages(updated);
    StorageService.saveMessages(updated);
  };

  // Export Chat History (Section 50)
  const handleExportChat = () => {
    if (!activeContact) return;
    const lines = currentChatMessages.map(
      (m) => `[${m.timestamp}] ${m.senderName} (${m.sender}): ${m.text || `[Media: ${m.mediaType}]`}`
    );
    const textData = `=== ChatPro Conversation Transcript ===\nParticipants: ${currentUser.name} & ${activeContact.name}\nExport Date: ${new Date().toLocaleString()}\n\n` + lines.join('\n');
    const blob = new Blob([textData], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChatPro_${activeContact.name.replace(/\s+/g, '_')}_Transcript.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Apply Theme styling
  const getThemeClass = (t: ThemePreset) => {
    switch (t) {
      case 'neon-purple':
        return 'theme-neon-purple';
      case 'emerald':
        return 'theme-emerald';
      case 'crimson':
        return 'theme-crimson';
      case 'midnight-gold':
        return 'theme-midnight-gold';
      case 'cyberpunk':
      default:
        return 'theme-cyberpunk';
    }
  };

  // If on Auth Screen
  if (currentScreen === 'auth') {
    return (
      <AuthScreen
        onLogin={handleLogin}
        onSignUp={handleSignUp}
        existingProfiles={profiles}
      />
    );
  }

  // If on Identity Verification Screen
  if (currentScreen === 'identity') {
    return (
      <IdentityVerificationScreen
        user={currentUser}
        onVerificationComplete={handleVerificationComplete}
        onSkipForTesting={() => {
          const updated: UserProfile = { ...currentUser, nicCaptured: true };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
          setCurrentScreen('messenger');
        }}
      />
    );
  }

  return (
    <div className={`h-screen w-screen flex flex-col bg-[#080b14] text-slate-100 overflow-hidden font-sans ${getThemeClass(activeTheme)}`}>
      {/* Top Navigation Bar */}
      <Navbar
        currentUser={currentUser}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onToggleAI={() => setIsAIOpen(!isAIOpen)}
        isAIOpen={isAIOpen}
        onLogout={handleLogout}
        onUpdatePresence={(status: PresenceStatus) => {
          const updated = { ...currentUser, presenceState: status };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        activeTheme={activeTheme}
        onSelectTheme={(t) => {
          setActiveTheme(t);
          StorageService.setTheme(t);
        }}
      />

      {/* Main Messenger Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Contact Sidebar (Mobile conditional sliding transition) */}
        <div
          className={`h-full ${
            isMobileChatOpen ? 'hidden md:flex' : 'flex'
          } w-full md:w-80 lg:w-96 shrink-0 transition-all duration-300 z-10`}
        >
          <ContactSidebar
            currentUser={currentUser}
            contacts={currentUser.contacts || []}
            unknownChats={unknownChats}
            activeChatEmail={activeContact?.email || null}
            onSelectContact={(c) => {
              setActiveContact(c);
              setIsMobileChatOpen(true);
            }}
            onAddContact={handleAddContact}
            onUnlockContactList={async (pwd) => {
              if (currentUser.lockPasswordHash) {
                const ok = await verifyPasswordPBKDF2(pwd, currentUser.lockPasswordHash);
                if (ok) {
                  const updated = { ...currentUser, contactListLocked: false };
                  StorageService.updateProfile(updated);
                  setProfiles(StorageService.getProfiles());
                  return true;
                }
              }
              return false;
            }}
            onLockContactList={() => {
              const updated = { ...currentUser, contactListLocked: true };
              StorageService.updateProfile(updated);
              setProfiles(StorageService.getProfiles());
            }}
            allMessages={allMessages}
            pinnedMessageIds={pinnedIds}
          />
        </div>

        {/* Active Conversation Pane */}
        <main
          className={`h-full flex-1 flex flex-col bg-[#0b0f1d] ${
            !isMobileChatOpen ? 'hidden md:flex' : 'flex'
          } transition-all duration-300 relative min-w-0`}
        >
          {activeContact ? (
            <>
              {/* WhatsApp-Style Contact Header */}
              <ChatHeader
                contact={activeContact}
                currentUser={currentUser}
                onBackMobile={() => setIsMobileChatOpen(false)}
                onStartVoiceCall={() => startCall('voice')}
                onStartVideoCall={() => startCall('video')}
                onToggleSearch={() => setShowSearchInChat(!showSearchInChat)}
                onToggleLockChat={() => {
                  const isLocked = currentUser.lockedChats?.includes(activeContact.email.toLowerCase());
                  const updatedLocked = isLocked
                    ? currentUser.lockedChats.filter((e) => e !== activeContact.email.toLowerCase())
                    : [...(currentUser.lockedChats || []), activeContact.email.toLowerCase()];
                  const updated = { ...currentUser, lockedChats: updatedLocked };
                  StorageService.updateProfile(updated);
                  setProfiles(StorageService.getProfiles());
                }}
                onClearChat={() => {
                  if (confirm(`Clear all messages with ${activeContact.name}?`)) {
                    const filtered = allMessages.filter((m) => m.chatId !== activeChatId);
                    setAllMessages(filtered);
                    StorageService.saveMessages(filtered);
                  }
                }}
                onExportChat={handleExportChat}
                onOpenAI={() => setIsAIOpen(true)}
                onViewScheduled={() => setIsScheduleModalOpen(true)}
                onViewMediaDocs={() => {
                  const firstPhoto = currentChatMessages.find((m) => m.mediaType === 'photo');
                  if (firstPhoto?.mediaUrl) {
                    setLightboxState({ open: true, url: firstPhoto.mediaUrl, type: 'photo' });
                  } else {
                    alert('No shared media documents in this chat yet.');
                  }
                }}
                onViewContactInfo={() => setIsContactInfoModalOpen(true)}
                isMuted={isMuted}
                onToggleMute={() => setIsMuted(!isMuted)}
              />

              {/* Optional Search in Chat Sub-bar */}
              {showSearchInChat && (
                <div className="p-2 bg-[#121829] border-b border-slate-800 flex items-center gap-2 px-4 animate-in fade-in duration-150">
                  <input
                    type="text"
                    value={searchInChatQuery}
                    onChange={(e) => setSearchInChatQuery(e.target.value)}
                    placeholder="Search in this conversation..."
                    className="flex-1 px-3 py-1.5 bg-[#0a0d18] border border-slate-700 rounded-lg text-xs text-slate-100"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setShowSearchInChat(false);
                      setSearchInChatQuery('');
                    }}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Close
                  </button>
                </div>
              )}

              {/* Message Feed */}
              <MessageFeed
                messages={currentChatMessages}
                currentUser={currentUser}
                starredIds={starredIds}
                pinnedIds={pinnedIds}
                onToggleStar={(id) => {
                  StorageService.toggleStarMessage(id);
                  setStarredIds(StorageService.getStarredMessageIds());
                }}
                onTogglePin={(id) => {
                  StorageService.togglePinMessage(id);
                  setPinnedIds(StorageService.getPinnedMessageIds());
                }}
                onDeleteMessage={(id) => {
                  const updated = allMessages.filter((m) => m.id !== id);
                  setAllMessages(updated);
                  StorageService.saveMessages(updated);
                }}
                onForwardMessage={(msg) => {
                  setForwardMessageTarget(msg);
                  setIsForwardModalOpen(true);
                }}
                onReplyMessage={(msg) => {
                  setReplyingTo(msg);
                }}
                onTranslateMessage={(msg) => {
                  setIsAIOpen(true);
                }}
                onRemindMessage={(msg) => {
                  setIsAIOpen(true);
                }}
                onVotePoll={handleVotePoll}
                onOpenMediaLightbox={(url, type) => {
                  setLightboxState({ open: true, url, type });
                }}
                searchQuery={searchInChatQuery}
              />

              {/* Message Composer */}
              <MessageComposer
                onSendMessage={handleSendMessage}
                replyingTo={replyingTo}
                onCancelReply={() => setReplyingTo(null)}
                onOpenPollModal={() => setIsPollModalOpen(true)}
                onOpenScheduleModal={() => setIsScheduleModalOpen(true)}
              />
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center text-slate-500">
              <p className="text-sm font-semibold text-slate-300">Select a conversation to start chatting</p>
              <p className="text-xs text-slate-500 mt-1">ChatPro Realtime messaging platform</p>
            </div>
          )}
        </main>
      </div>

      {/* Embedded ChatPro AI Copilot Floating Panel (Section 31) */}
      <AIAssistantModal
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        currentUser={currentUser}
        activeChatMessages={currentChatMessages}
        onInsertComposerText={(text) => {
          handleSendMessage(text);
          setIsAIOpen(false);
        }}
        onSaveMemory={(key, value) => {
          const newMem = {
            id: `mem_${Date.now()}`,
            chatId: activeChatId,
            email: activeContact?.email || currentUser.email,
            key,
            value,
            createdAt: new Date().toISOString()
          };
          const updated = {
            ...currentUser,
            chatMemory: [newMem, ...(currentUser.chatMemory || [])].slice(0, 200)
          };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        onDeleteMemory={(id) => {
          const updated = {
            ...currentUser,
            chatMemory: currentUser.chatMemory?.filter((m) => m.id !== id) || []
          };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        onAddReminder={(text, when) => {
          const newRem = {
            id: `rem_${Date.now()}`,
            chatId: activeChatId,
            text,
            when,
            createdAt: new Date().toISOString()
          };
          const updated = {
            ...currentUser,
            chatReminders: [newRem, ...(currentUser.chatReminders || [])]
          };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        onCompleteReminder={(id) => {
          const updated = {
            ...currentUser,
            chatReminders: currentUser.chatReminders?.filter((r) => r.id !== id) || []
          };
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        onTriggerMorph={(morphType) => {
          if (morphType === 'Sticker') {
            handleSendMessage('🚀', 'sticker');
          } else if (morphType === 'Poll') {
            setIsPollModalOpen(true);
          } else if (morphType === 'Professional') {
            handleSendMessage('Greetings. Please find the finalized deliverable available for strategic confirmation.');
          } else {
            handleSendMessage(`[Morphed into ${morphType}]: High priority status update.`);
          }
          setIsAIOpen(false);
        }}
      />

      {/* WebRTC Voice & Video Call Modal (Section 57, 58, 59) */}
      <CallModal
        call={activeCall}
        onAnswer={answerCall}
        onDecline={endCall}
        onHangup={endCall}
        onToggleMute={() => setActiveCall((p) => ({ ...p, isMuted: !p.isMuted }))}
        onToggleVideo={() => setActiveCall((p) => ({ ...p, isVideoOff: !p.isVideoOff }))}
      />

      {/* Admin Control Center Modal (Section 61) */}
      <AdminCenterModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        currentUser={currentUser}
        profiles={profiles}
        allMessages={allMessages}
        onSendBroadcast={handleAdminBroadcast}
        onRefreshData={() => {
          setProfiles(StorageService.getProfiles());
          setAllMessages(StorageService.getMessages());
        }}
      />

      {/* Settings Modal (Section 26-30) */}
      <SettingsScreen
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentUser={currentUser}
        allMessages={allMessages}
        onUpdateProfile={(updated) => {
          StorageService.updateProfile(updated);
          setProfiles(StorageService.getProfiles());
        }}
        onClearMedia={() => {
          const count = StorageService.clearMediaForUser(currentUser.email);
          setAllMessages(StorageService.getMessages());
          return count;
        }}
        onDeleteAccount={() => {
          StorageService.deleteUserAccount(currentUser.email);
          setCurrentScreen('auth');
          setIsSettingsOpen(false);
        }}
      />

      {/* Auxiliary Modals */}
      <MediaLightboxModal
        isOpen={lightboxState.open}
        mediaUrl={lightboxState.url}
        mediaType={lightboxState.type}
        onClose={() => setLightboxState({ open: false, url: null, type: 'photo' })}
      />

      <PollCreatorModal
        isOpen={isPollModalOpen}
        onClose={() => setIsPollModalOpen(false)}
        onCreatePoll={(question, options) => {
          const pollData = {
            question,
            options: options.map((opt, i) => ({ id: `opt_${i + 1}`, text: opt, votes: [] })),
            totalVotes: 0
          };
          handleSendMessage(`📊 ${question}`, 'poll', undefined, { poll: pollData });
        }}
      />

      <ScheduleModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        onScheduleMessage={(text, date, time) => {
          if (!activeContact) return;
          const scheduledIso = new Date(`${date}T${time}:00`).toISOString();
          const schedMsg: ChatMessage = {
            id: `sched_${Date.now()}`,
            chatId: activeChatId,
            sender: currentUser.email,
            senderName: currentUser.name,
            recipient: activeContact.email,
            recipientName: activeContact.name,
            timestamp: `${time} (${date})`,
            language: detectLanguage(text),
            text,
            status: 'scheduled',
            scheduledAt: scheduledIso,
            messageType: 'text'
          };
          const updated = [...allMessages, schedMsg];
          setAllMessages(updated);
          StorageService.saveMessages(updated);
        }}
      />

      <ForwardModal
        isOpen={isForwardModalOpen}
        onClose={() => setIsForwardModalOpen(false)}
        message={forwardMessageTarget}
        contacts={currentUser.contacts || []}
        onConfirmForward={(targetEmail) => {
          if (!forwardMessageTarget) return;
          const targetContact = currentUser.contacts.find((c) => c.email === targetEmail);
          const fwdChatId = deterministicChatId(currentUser.email, targetEmail);
          const fwdMsg: ChatMessage = {
            id: `fwd_${Date.now()}`,
            chatId: fwdChatId,
            sender: currentUser.email,
            senderName: currentUser.name,
            recipient: targetEmail,
            recipientName: targetContact?.name || targetEmail,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            language: forwardMessageTarget.language,
            text: forwardMessageTarget.text,
            mediaType: forwardMessageTarget.mediaType,
            mediaUrl: forwardMessageTarget.mediaUrl,
            messageType: forwardMessageTarget.messageType,
            status: 'sent',
            metadata: {
              forwardedFrom: forwardMessageTarget.senderName
            }
          };
          const updated = [...allMessages, fwdMsg];
          setAllMessages(updated);
          StorageService.saveMessages(updated);
          alert(`Message forwarded to ${targetContact?.name || targetEmail}!`);
        }}
      />

      <ContactInfoModal
        isOpen={isContactInfoModalOpen}
        onClose={() => setIsContactInfoModalOpen(false)}
        contact={activeContact}
        messageCount={currentChatMessages.length}
        onExportChat={handleExportChat}
      />
    </div>
  );
}
