export type PresenceStatus =
  | 'available'
  | 'busy'
  | 'listening to music'
  | 'working'
  | 'studying'
  | 'focus mode'
  | 'do not disturb'
  | 'offline';

export type DocumentType = 'nic' | 'passport' | 'driving_licence';

export interface IdentityDetails {
  documentType: DocumentType;
  documentNumber: string;
  fullName: string;
  dateOfBirth?: string;
  issueDate?: string;
  extractedText?: string;
  verifiedAt?: string;
  confidence?: number;
}

export interface UserContact {
  email: string;
  name: string;
  emoji?: string;
  profilePhoto?: string;
  about?: string;
  lastMessage?: string;
  lastMessageTime?: string;
  isPinned?: boolean;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  about: string;
  emoji: string;
  contacts: UserContact[];
  isAdmin: boolean;
  nicNumber?: string;
  nicDetails?: IdentityDetails;
  nicCaptured: boolean;
  profileSetup: boolean;
  profilePhoto?: string;
  nicPhotoUrl?: string;
  lockedChats: string[]; // array of emails
  contactListLocked: boolean;
  lockPasswordHash?: string;
  autoReplyEnabled: boolean;
  autoReplyText: string;
  lastAutoReplies?: Record<string, number>; // senderEmail -> timestamp
  chatMemory: ChatMemoryItem[];
  chatReminders: ChatReminderItem[];
  chatRecurring: RecurringScheduleItem[];
  presenceState: PresenceStatus;
  presenceVisible: boolean;
  lastSeen: string;
  createdAt: string;
}

export interface ChatMemoryItem {
  id: string;
  chatId: string;
  email: string;
  key: string;
  value: string;
  createdAt: string;
}

export interface ChatReminderItem {
  id: string;
  chatId: string;
  messageId?: string;
  text: string;
  when: string; // ISO string
  createdAt: string;
  completed?: boolean;
}

export interface RecurringScheduleItem {
  id: string;
  recipientEmail: string;
  dayOfWeek: string;
  time: string;
  message: string;
  createdAt: string;
}

export type MessageType =
  | 'text'
  | 'photo'
  | 'video'
  | 'voice'
  | 'location'
  | 'poll'
  | 'sticker';

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // user emails who voted
}

export interface PollData {
  question: string;
  options: PollOption[];
  totalVotes: number;
}

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy?: number;
  label?: string;
  mapUrl: string;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  sender: string; // email
  senderName: string;
  recipient: string; // email
  recipientName: string;
  timestamp: string;
  language: 'en' | 'si'; // English or Sinhala
  text: string;
  mediaType?: MessageType;
  mediaUrl?: string;
  mediaPath?: string;
  mediaMimeType?: string;
  duration?: number; // for voice in seconds
  isBroadcast?: boolean;
  status: 'sent' | 'delivered' | 'read' | 'scheduled';
  scheduledAt?: string;
  messageType: MessageType;
  metadata?: {
    poll?: PollData;
    location?: LocationData;
    replyToId?: string;
    replyToText?: string;
    replyToSender?: string;
    forwardedFrom?: string;
  };
}

export interface ActiveCall {
  active: boolean;
  type: 'voice' | 'video';
  contact: UserContact;
  status: 'calling' | 'incoming' | 'connected' | 'ended';
  startTime?: number;
  isMuted?: boolean;
  isVideoOff?: boolean;
}

export type ThemePreset = 'cyberpunk' | 'neon-purple' | 'emerald' | 'crimson' | 'midnight-gold';
