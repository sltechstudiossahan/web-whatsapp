import {
  UserProfile,
  ChatMessage,
  IdentityDetails,
  PollData,
  LocationData,
  MessageType
} from '../types';

export function deterministicChatId(email1: string, email2: string): string {
  const sorted = [email1.toLowerCase().trim(), email2.toLowerCase().trim()].sort();
  return sorted.join('_');
}

// PBKDF2 SHA-256 150,000 iterations as specified in Section 23
export async function hashPasswordPBKDF2(password: string): Promise<string> {
  if (typeof window === 'undefined' || !window.crypto || !window.crypto.subtle) {
    // Fallback simple hash for environments without WebCrypto
    return `hash_${btoa(password).slice(0, 32)}`;
  }
  try {
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw',
      enc.encode(password),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );
    const salt = enc.encode('chatpro_privacy_salt_2026');
    const key = await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt,
        iterations: 150000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    const exported = await window.crypto.subtle.exportKey('raw', key);
    return Array.from(new Uint8Array(exported))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  } catch {
    return `hash_${btoa(password).slice(0, 32)}`;
  }
}

export async function verifyPasswordPBKDF2(input: string, storedHash: string): Promise<boolean> {
  const computed = await hashPasswordPBKDF2(input);
  return computed === storedHash;
}

// Initial Seed Users
export const INITIAL_PROFILES: UserProfile[] = [
  {
    id: 'user_admin_1',
    email: 'admin1@chatapp.com',
    name: 'Admin Kasun',
    about: 'System Administrator & Security Lead',
    emoji: '🛡️',
    isAdmin: true,
    nicNumber: '199512345678',
    nicCaptured: true,
    profileSetup: true,
    profilePhoto: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    nicPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
    lockedChats: [],
    contactListLocked: false,
    autoReplyEnabled: false,
    autoReplyText: 'Hello! I am currently away from the keyboard. I will get back to you shortly.',
    chatMemory: [
      {
        id: 'mem_1',
        chatId: 'admin1@chatapp.com_sarah@chatapp.com',
        email: 'sarah@chatapp.com',
        key: 'Sprint Review',
        value: 'Next sprint review is on Friday at 3 PM',
        createdAt: new Date(Date.now() - 86400000).toISOString()
      }
    ],
    chatReminders: [],
    chatRecurring: [],
    presenceState: 'available',
    presenceVisible: true,
    lastSeen: new Date().toISOString(),
    createdAt: '2026-01-01T08:00:00.000Z',
    contacts: [
      {
        email: 'user1@chatapp.com',
        name: 'Kasun Perera',
        emoji: '🇱🇰',
        about: 'Tech enthusiast & developer from Colombo',
        profilePhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        lastMessage: 'ඔව්, මම ඒක බලාගන්නම්! (Yes, I will handle it!)',
        lastMessageTime: '10:45 AM'
      },
      {
        email: 'dilshan@chatapp.com',
        name: 'Dilshan Silva',
        emoji: '⚡',
        about: 'UX Designer & Coffee lover',
        profilePhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        lastMessage: 'Check out the new design system proposal.',
        lastMessageTime: 'Yesterday'
      },
      {
        email: 'sarah@chatapp.com',
        name: 'Sarah Jenkins',
        emoji: '✨',
        about: 'Product Manager @ GlobalTech',
        profilePhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        lastMessage: 'Great progress on the release candidate!',
        lastMessageTime: 'Mar 15'
      }
    ]
  },
  {
    id: 'user_regular_1',
    email: 'user1@chatapp.com',
    name: 'Kasun Perera',
    about: 'Tech enthusiast & developer from Colombo',
    emoji: '🇱🇰',
    isAdmin: false,
    nicNumber: '199234567890',
    nicCaptured: true,
    profileSetup: true,
    profilePhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    nicPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
    lockedChats: [],
    contactListLocked: false,
    autoReplyEnabled: true,
    autoReplyText: 'ආයුබෝවන්! මම මේ වෙලාවේ කාර්යබහුලයි. මම ඉක්මනින් සම්බන්ධ වෙන්නම්. (Hi, currently busy. Will reply soon.)',
    chatMemory: [],
    chatReminders: [],
    chatRecurring: [],
    presenceState: 'working',
    presenceVisible: true,
    lastSeen: new Date().toISOString(),
    createdAt: '2026-01-10T10:00:00.000Z',
    contacts: [
      {
        email: 'admin1@chatapp.com',
        name: 'Admin Kasun',
        emoji: '🛡️',
        about: 'System Administrator & Security Lead',
        profilePhoto: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        lastMessage: 'Please submit the weekly telemetry stats.',
        lastMessageTime: '10:40 AM'
      },
      {
        email: 'dilshan@chatapp.com',
        name: 'Dilshan Silva',
        emoji: '⚡',
        about: 'UX Designer & Coffee lover',
        profilePhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        lastMessage: 'Let us sync on the call whenever you are ready.',
        lastMessageTime: '9:15 AM'
      }
    ]
  },
  {
    id: 'user_regular_2',
    email: 'dilshan@chatapp.com',
    name: 'Dilshan Silva',
    about: 'UX Designer & Coffee lover',
    emoji: '⚡',
    isAdmin: false,
    nicNumber: '199687654321',
    nicCaptured: true,
    profileSetup: true,
    profilePhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    lockedChats: [],
    contactListLocked: false,
    autoReplyEnabled: false,
    autoReplyText: 'Hey there! Drop your note here.',
    chatMemory: [],
    chatReminders: [],
    chatRecurring: [],
    presenceState: 'listening to music',
    presenceVisible: true,
    lastSeen: new Date().toISOString(),
    createdAt: '2026-01-15T12:00:00.000Z',
    contacts: [
      {
        email: 'admin1@chatapp.com',
        name: 'Admin Kasun',
        emoji: '🛡️',
        profilePhoto: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
      }
    ]
  },
  {
    id: 'user_regular_3',
    email: 'sarah@chatapp.com',
    name: 'Sarah Jenkins',
    about: 'Product Manager @ GlobalTech',
    emoji: '✨',
    isAdmin: false,
    nicNumber: '199854321098',
    nicCaptured: true,
    profileSetup: true,
    profilePhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    lockedChats: [],
    contactListLocked: false,
    autoReplyEnabled: false,
    autoReplyText: '',
    chatMemory: [],
    chatReminders: [],
    chatRecurring: [],
    presenceState: 'available',
    presenceVisible: true,
    lastSeen: new Date().toISOString(),
    createdAt: '2026-02-01T09:00:00.000Z',
    contacts: []
  },
  {
    id: 'user_unknown_1',
    email: 'kavindu.alwis@chatapp.com',
    name: 'Kavindu Alwis',
    about: 'Freelance Mobile App Engineer',
    emoji: '🚀',
    isAdmin: false,
    nicNumber: '199411223344',
    nicCaptured: true,
    profileSetup: true,
    profilePhoto: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    lockedChats: [],
    contactListLocked: false,
    autoReplyEnabled: false,
    autoReplyText: '',
    chatMemory: [],
    chatReminders: [],
    chatRecurring: [],
    presenceState: 'busy',
    presenceVisible: true,
    lastSeen: new Date().toISOString(),
    createdAt: '2026-02-10T14:00:00.000Z',
    contacts: []
  }
];

// Initial Seed Messages
export const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg_1',
    chatId: deterministicChatId('admin1@chatapp.com', 'user1@chatapp.com'),
    sender: 'admin1@chatapp.com',
    senderName: 'Admin Kasun',
    recipient: 'user1@chatapp.com',
    recipientName: 'Kasun Perera',
    timestamp: new Date(Date.now() - 3600000 * 2).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    language: 'en',
    text: 'Hello Kasun! Welcome to ChatPro. How is the system performance on your end?',
    status: 'read',
    messageType: 'text'
  },
  {
    id: 'msg_2',
    chatId: deterministicChatId('admin1@chatapp.com', 'user1@chatapp.com'),
    sender: 'user1@chatapp.com',
    senderName: 'Kasun Perera',
    recipient: 'admin1@chatapp.com',
    recipientName: 'Admin Kasun',
    timestamp: new Date(Date.now() - 3600000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    language: 'si',
    text: 'ආයුබෝවන්! පද්ධතිය ඉතා වේගවත් හා සුමටයි. ස්තූතියි! (Everything is running smoothly!)',
    status: 'read',
    messageType: 'text'
  },
  {
    id: 'msg_3',
    chatId: deterministicChatId('admin1@chatapp.com', 'user1@chatapp.com'),
    sender: 'admin1@chatapp.com',
    senderName: 'Admin Kasun',
    recipient: 'user1@chatapp.com',
    recipientName: 'Kasun Perera',
    timestamp: new Date(Date.now() - 1800000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    language: 'en',
    text: 'Here is the photo of our new server infrastructure deployment:',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=80',
    mediaPath: 'chat-media/admin1/server_datacenter.jpg',
    status: 'read',
    messageType: 'photo'
  },
  {
    id: 'msg_4',
    chatId: deterministicChatId('admin1@chatapp.com', 'user1@chatapp.com'),
    sender: 'user1@chatapp.com',
    senderName: 'Kasun Perera',
    recipient: 'admin1@chatapp.com',
    recipientName: 'Admin Kasun',
    timestamp: new Date(Date.now() - 900000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    language: 'en',
    text: 'Impressive setup! Also, cast your vote on the UI theme release:',
    messageType: 'poll',
    metadata: {
      poll: {
        question: 'Which default palette should we launch for ChatPro v2.0?',
        options: [
          { id: 'opt_1', text: 'Cyberpunk Purple & Teal', votes: ['user1@chatapp.com', 'admin1@chatapp.com'] },
          { id: 'opt_2', text: 'Emerald Matrix Green', votes: [] },
          { id: 'opt_3', text: 'Midnight Gold', votes: [] }
        ],
        totalVotes: 2
      }
    },
    status: 'read'
  },
  {
    id: 'msg_5',
    chatId: deterministicChatId('admin1@chatapp.com', 'user1@chatapp.com'),
    sender: 'admin1@chatapp.com',
    senderName: 'Admin Kasun',
    recipient: 'user1@chatapp.com',
    recipientName: 'Kasun Perera',
    timestamp: new Date(Date.now() - 300000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    language: 'si',
    text: 'ඔව්, මම ඒක බලාගන්නම්! (Yes, I will handle it!)',
    status: 'read',
    messageType: 'text'
  },
  // Incoming message from Unknown sender
  {
    id: 'msg_unknown_1',
    chatId: deterministicChatId('admin1@chatapp.com', 'kavindu.alwis@chatapp.com'),
    sender: 'kavindu.alwis@chatapp.com',
    senderName: 'Kavindu Alwis',
    recipient: 'admin1@chatapp.com',
    recipientName: 'Admin Kasun',
    timestamp: '11:20 AM',
    language: 'en',
    text: 'Hi Admin, I saw your ChatPro announcement on LinkedIn. Could you grant me API documentation access?',
    status: 'delivered',
    messageType: 'text'
  }
];

// Local Storage Keys
const STORAGE_KEYS = {
  PROFILES: 'chatpro_profiles_v1',
  MESSAGES: 'chatpro_messages_v1',
  CURRENT_USER_EMAIL: 'chatpro_current_user_v1',
  THEME: 'chatpro_theme_v1',
  STARRED: 'chatproStarredMessages',
  PINNED: 'chatproPinnedMessages'
};

export class StorageService {
  static getProfiles(): UserProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILES);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(INITIAL_PROFILES));
    return INITIAL_PROFILES;
  }

  static saveProfiles(profiles: UserProfile[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
    } catch (e) {
      console.error(e);
    }
  }

  static getProfileByEmail(email: string): UserProfile | undefined {
    const profiles = this.getProfiles();
    return profiles.find((p) => p.email.toLowerCase() === email.toLowerCase());
  }

  static updateProfile(updated: UserProfile) {
    const profiles = this.getProfiles();
    const idx = profiles.findIndex((p) => p.id === updated.id || p.email.toLowerCase() === updated.email.toLowerCase());
    if (idx >= 0) {
      profiles[idx] = updated;
    } else {
      profiles.push(updated);
    }
    this.saveProfiles(profiles);
  }

  static getCurrentUserEmail(): string {
    return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_EMAIL) || 'admin1@chatapp.com';
  }

  static setCurrentUserEmail(email: string) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_EMAIL, email);
  }

  static getMessages(): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(INITIAL_MESSAGES));
    return INITIAL_MESSAGES;
  }

  static saveMessages(messages: ChatMessage[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error(e);
    }
  }

  static addMessage(msg: ChatMessage) {
    const msgs = this.getMessages();
    msgs.push(msg);
    this.saveMessages(msgs);
  }

  static getStarredMessageIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.STARRED);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static toggleStarMessage(id: string): boolean {
    const ids = this.getStarredMessageIds();
    const idx = ids.indexOf(id);
    let starred = false;
    if (idx >= 0) {
      ids.splice(idx, 1);
    } else {
      ids.push(id);
      starred = true;
    }
    localStorage.setItem(STORAGE_KEYS.STARRED, JSON.stringify(ids));
    return starred;
  }

  static getPinnedMessageIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PINNED);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static togglePinMessage(id: string): boolean {
    const ids = this.getPinnedMessageIds();
    const idx = ids.indexOf(id);
    let pinned = false;
    if (idx >= 0) {
      ids.splice(idx, 1);
    } else {
      ids.push(id);
      pinned = true;
    }
    localStorage.setItem(STORAGE_KEYS.PINNED, JSON.stringify(ids));
    return pinned;
  }

  static getTheme(): string {
    return localStorage.getItem(STORAGE_KEYS.THEME) || 'cyberpunk';
  }

  static setTheme(theme: string) {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  }

  static clearMediaForUser(userEmail: string): number {
    const msgs = this.getMessages();
    let count = 0;
    const updated = msgs.map((m) => {
      if ((m.sender === userEmail || m.recipient === userEmail) && m.mediaUrl) {
        count++;
        return {
          ...m,
          mediaUrl: undefined,
          mediaPath: undefined,
          text: m.text ? m.text : '[Media cleared by user]'
        };
      }
      return m;
    });
    this.saveMessages(updated);
    return count;
  }

  static deleteUserAccount(userEmail: string) {
    const profiles = this.getProfiles().filter((p) => p.email.toLowerCase() !== userEmail.toLowerCase());
    this.saveProfiles(profiles);
    const msgs = this.getMessages().filter((m) => m.sender !== userEmail && m.recipient !== userEmail);
    this.saveMessages(msgs);
  }
}
