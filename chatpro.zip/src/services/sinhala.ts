/**
 * Sinhala Language Detection and Translation Utilities
 * Unicode range for Sinhala: \u0D80 to \u0DFF
 */

export function isSinhalaText(text: string): boolean {
  if (!text) return false;
  const sinhalaRegex = /[\u0D80-\u0DFF]/;
  return sinhalaRegex.test(text);
}

export function detectLanguage(text: string): 'en' | 'si' {
  return isSinhalaText(text) ? 'si' : 'en';
}

// Built-in phrase translation mapping for ChatPro AI translation feature
export const SINHALA_PHRASE_DICTIONARY: Record<string, string> = {
  // English to Sinhala
  'hello': 'ආයුබෝවන් (Ayubowan)',
  'hi': 'හායි (Hai)',
  'good morning': 'සුභ උදෑසනක් (Subha Udaasanak)',
  'good night': 'සුභ රාත්‍රියක් (Subha Rathriyak)',
  'how are you': 'කොහොමද ඔයාට? (Kohomada Oyata?)',
  'how are you?': 'කොහොමද ඔයාට? (Kohomada Oyata?)',
  'i am fine': 'මම හොඳින් (Mama hondin)',
  'thank you': 'ස්තූතියි (Sthuthiyi)',
  'thanks': 'බොහොම ස්තූතියි (Bohoma Sthuthiyi)',
  'please': 'කරුණාකර (Karunakarala)',
  'sorry': 'සමාවෙන්න (Samawenna)',
  'yes': 'ඔව් (Ow)',
  'no': 'නැහැ (Naehae)',
  'goodbye': 'ගිහින් එන්නම් (Gihin Ennam)',
  'where are you': 'ඔයා කොහෙද ඉන්නේ? (Oya koheda inne?)',
  'where are you?': 'ඔයා කොහෙද ඉන්නේ? (Oya koheda inne?)',
  'what time': 'වෙලාව කීයද? (Welawa keeyada?)',
  'call me': 'මට කෝල් එකක් දෙන්න (Mata call ekak denna)',
  'see you later': 'පස්සේ හමුවෙමු (Passe hamuwemu)',
  'welcome': 'සාදරයෙන් පිළිගනිමු (Saadarayen piliganimu)',
  'congratulations': 'සුභ පැතුම් (Subha Paethum)',
  'take care': 'පරිස්සමෙන් ඉන්න (Parissamen inna)',
  'meeting': 'රැස්වීම (Rasveema)',
  'urgent': 'හදිසි (Hadisi)',

  // Sinhala to English
  'ආයුබෝවන්': 'Hello / Greetings',
  'කොහොමද': 'How are you?',
  'ස්තූතියි': 'Thank you',
  'සමාවෙන්න': 'Sorry / Excuse me',
  'ඔව්': 'Yes',
  'නැහැ': 'No',
  'සුභ උදෑසනක්': 'Good morning',
  'සුභ රාත්‍රියක්': 'Good night',
  'හොඳයි': 'Good / Okay',
  'කරුණාකර': 'Please',
  'පස්සේ කතා කරමු': 'Let us talk later',
};

export function translateText(text: string): { translated: string; from: 'en' | 'si'; to: 'en' | 'si' } {
  const clean = text.trim().toLowerCase();
  const isSi = isSinhalaText(text);

  if (isSi) {
    for (const [siKey, enVal] of Object.entries(SINHALA_PHRASE_DICTIONARY)) {
      if (text.includes(siKey)) {
        return { translated: enVal, from: 'si', to: 'en' };
      }
    }
    return {
      translated: `[Sinhala Translation]: "${text}" (Common Sinhala message)`,
      from: 'si',
      to: 'en'
    };
  } else {
    for (const [enKey, siVal] of Object.entries(SINHALA_PHRASE_DICTIONARY)) {
      if (clean.includes(enKey)) {
        return { translated: siVal, from: 'en', to: 'si' };
      }
    }
    // Simple transliteration aid
    return {
      translated: `[සිංහල පරිවර්තනය]: "${text}" (English text in Sinhala context)`,
      from: 'en',
      to: 'si'
    };
  }
}
